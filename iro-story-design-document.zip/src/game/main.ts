// ============================================================
// いろ — エンジン本体(キャンバス/入力/UI/FX/ステージ/シーン管理/タイトル)
// ============================================================
import type {
  Assets, AudioSys, ChoiceOpt, Ctx2D, FX, Game, Input, KeyName,
  SaveData, SaveSys, SaveData as SD, SayOpt, Scene, Stage, StageChar, UI,
} from "./types";
import { audioSys } from "./audio";
import { drawBG, drawCharLarge, drawMike, RAINBOW, text, FONT, rainbowText } from "./art";
import { story, nurseCallMini } from "./director";

const W = 320, H = 240;

// ---------------- アセット読み込み ----------------
const ASSET_LIST = [
  "characters/mio_real", "characters/mio_other", "characters/kaede", "characters/kaede_gauze",
  "characters/mother", "characters/doctor", "characters/nurse_night", "characters/staff_meal", "characters/hana",
  "monsters/mike", "monsters/gyorome", "monsters/honey_queen", "monsters/gatekeeper_l", "monsters/gatekeeper_s",
  "monsters/witch_0", "monsters/witch_1", "monsters/witch_2", "monsters/witch_3", "monsters/witch_4",
  "tiles/tileset_real", "tiles/tileset_other",
  "bg/real_room", "bg/real_hall", "bg/real_lounge", "bg/real_courtyard", "bg/real_station", "bg/real_canteen",
  "bg/real_visiting", "bg/real_roof", "bg/other_room", "bg/other_hall", "bg/other_lounge", "bg/other_courtyard",
  "bg/other_station", "bg/other_canteen", "bg/other_visiting", "bg/other_roof", "bg/title",
  "bg/battle_bg_123", "bg/battle_bg_4_0", "bg/battle_bg_4_1", "bg/battle_bg_4_2", "bg/battle_bg_4_3", "bg/battle_bg_4_4",
  "bg/transition_white", "bg/ending_grave", "bg/ending_entrance", "bg/bad1_room", "bg/bad7_box",
];

class AssetsImpl implements Assets {
  private map = new Map<string, HTMLImageElement | null>();
  async loadAll(onProgress: (n: number, total: number) => void) {
    let n = 0;
    const jobs = ASSET_LIST.map(
      (name) =>
        new Promise<void>((res) => {
          const img = new Image();
          img.onload = () => { this.map.set(name, img); n++; onProgress(n, ASSET_LIST.length); res(); };
          img.onerror = () => { this.map.set(name, null); n++; onProgress(n, ASSET_LIST.length); res(); };
          img.src = `assets/${name}.png`;
        })
    );
    await Promise.all(jobs);
  }
  has(name: string) { return this.map.get(name) != null; }
  img(name: string) { return this.map.get(name) ?? null; }
}

// ---------------- セーブ ----------------
const SAVE_KEY = "iro_save_v1";
function defaultSave(): SaveData {
  return { v: 1, checkpoint: "prologue", seenBad: [], unlockedCall: false, cleared: false };
}
class SaveImpl implements SaveSys {
  d: SaveData = defaultSave();
  private mem: string | null = null;
  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) { this.d = { ...defaultSave(), ...JSON.parse(raw) }; return; }
    } catch { /* localStorage 不可 */ }
    if (this.mem) { try { this.d = { ...defaultSave(), ...JSON.parse(this.mem) }; } catch { /* */ } }
  }
  commit() {
    const raw = JSON.stringify(this.d);
    try { localStorage.setItem(SAVE_KEY, raw); } catch { /* */ }
    this.mem = raw;
  }
  wipeRun() {
    const keep: SD = { ...this.d };
    this.d = defaultSave();
    this.d.seenBad = keep.seenBad;
    this.d.unlockedCall = keep.unlockedCall;
    this.d.cleared = keep.cleared;
    this.commit();
  }
  hasRun(): boolean {
    return this.d.checkpoint !== "prologue";
  }
}

// ---------------- 入力 ----------------
class InputImpl implements Input {
  private heldSet = new Set<KeyName>();
  private pressSet = new Set<KeyName>();
  private keymap: Record<string, KeyName | undefined> = {
    ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right",
    w: "up", s: "down", a: "left", d: "right", W: "up", S: "down", A: "left", D: "right",
    z: "z", Z: "z", Enter: "z", " ": "z",
    x: "x", X: "x",
    c: "c", C: "c",
  };
  constructor(private onFirst: () => void) {
    window.addEventListener("keydown", (e) => {
      const k = this.keymap[e.key];
      if (k) {
        if (["up", "down", "left", "right"].includes(k) || e.key === " ") e.preventDefault();
        if (!e.repeat) this.pressSet.add(k);
        this.heldSet.add(k);
        this.onFirst();
      }
    });
    window.addEventListener("keyup", (e) => {
      const k = this.keymap[e.key];
      if (k) this.heldSet.delete(k);
    });
  }
  bindButton(el: HTMLElement, k: KeyName) {
    const down = (e: Event) => {
      e.preventDefault();
      this.pressSet.add(k);
      this.heldSet.add(k);
      this.onFirst();
    };
    const up = (e: Event) => {
      e.preventDefault();
      this.heldSet.delete(k);
    };
    el.addEventListener("pointerdown", down);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    el.addEventListener("pointerleave", up);
    el.addEventListener("contextmenu", (e) => e.preventDefault());
  }
  tap(k: KeyName) {
    this.pressSet.add(k);
    this.onFirst();
  }
  held(k: KeyName) { return this.heldSet.has(k); }
  consume(k: KeyName) {
    if (this.pressSet.has(k)) { this.pressSet.delete(k); return true; }
    return false;
  }
  peek(k: KeyName) { return this.pressSet.has(k); }
  post() { this.pressSet.clear(); }
}

// ---------------- UI ----------------
interface SayState {
  type: "say";
  name: string | null;
  pages: string[][];
  page: number;
  shown: number;
  t: number;
  mike: boolean;
  resolve: () => void;
}
interface ChoiceState {
  type: "choice";
  opts: ChoiceOpt[];
  title: string | null;
  index: number;
  resolve: (n: number) => void;
}
class UIImpl implements UI {
  private st: SayState | ChoiceState | null = null;
  private toastState: { text: string; until: number } | null = null;
  private objectiveText: string | null = null;
  private gaugeV: number | null = null;
  constructor(private g: Game, private input: InputImpl, private audio: AudioSys) {}

  busy() { return this.st !== null; }

  private wrap(s: string, size: number, maxW: number): string[][] {
    const buf = document.createElement("canvas").getContext("2d")!;
    buf.font = `${size}px ${FONT}`;
    const lines: string[] = [];
    let cur = "";
    for (const part of s.split("\n")) {
      cur = "";
      for (const ch of part) {
        if (buf.measureText(cur + ch).width > maxW) {
          lines.push(cur); cur = ch;
        } else cur += ch;
      }
      if (cur) lines.push(cur);
    }
    const pages: string[][] = [];
    for (let i = 0; i < lines.length; i += 3) pages.push(lines.slice(i, i + 3));
    return pages.length ? pages : [[""]];
  }

  say(name: string | null, t: string, opt?: SayOpt): Promise<void> {
    return new Promise((resolve) => {
      this.st = {
        type: "say", name, pages: this.wrap(t, 11, 282), page: 0,
        shown: 0, t: 0, mike: !!opt?.mike, resolve,
      };
      if (opt?.mike) this.audio.sfx("whisper");
    });
  }
  narr(t: string) { return this.say(null, t); }
  async lines(arr: [string | null, string][], opt?: SayOpt) {
    for (const [w, t] of arr) await this.say(w, t, w === "ミケ" ? { mike: true } : opt);
  }
  choice(opts: ChoiceOpt[], title?: string): Promise<number> {
    return new Promise((resolve) => {
      let first = opts.findIndex((o) => !o.disabled);
      if (first < 0) first = 0;
      this.st = { type: "choice", opts, title: title ?? null, index: first, resolve };
    });
  }
  toast(t2: string, ms = 2600) { this.toastState = { text: t2, until: performance.now() + ms }; }
  objective(t2: string | null) { this.objectiveText = t2; }
  setGauge(v: number | null) { this.gaugeV = v; }
  hideBox() { this.st = null; }

  update(dt: number) {
    const st = this.st;
    if (!st) return;
    if (st.type === "say") {
      const pageText = st.pages[st.page].join("");
      if (st.shown < pageText.length) {
        st.t += dt;
        const speed = 0.018;
        const target = Math.min(pageText.length, Math.floor(st.t / speed));
        if (target !== st.shown) {
          st.shown = target;
          if (!st.mike && st.shown % 2 === 0) this.audio.sfx("text");
        }
        if (this.input.consume("z")) {
          st.shown = pageText.length;
        }
      } else if (this.input.consume("z")) {
        if (st.page < st.pages.length - 1) {
          st.page++; st.shown = 0; st.t = 0;
          this.audio.sfx("text");
        } else {
          const r = st.resolve;
          this.st = null;
          this.audio.sfx("confirm");
          r();
        }
      }
    } else {
      const opts = st.opts;
      if (this.input.consume("up")) {
        let i = st.index;
        for (let n = 0; n < opts.length; n++) {
          i = (i - 1 + opts.length) % opts.length;
          if (!opts[i].disabled) { st.index = i; break; }
        }
        this.audio.sfx("cursor");
      }
      if (this.input.consume("down")) {
        let i = st.index;
        for (let n = 0; n < opts.length; n++) {
          i = (i + 1) % opts.length;
          if (!opts[i].disabled) { st.index = i; break; }
        }
        this.audio.sfx("cursor");
      }
      if (this.input.consume("z")) {
        const o = opts[st.index];
        if (o.disabled) { this.audio.sfx("disabled"); return; }
        const r = st.resolve;
        this.st = null;
        this.audio.sfx("confirm");
        r(st.index);
      }
      if (this.input.consume("x")) {
        // キャンセル:最後の有効項目を返す
        let last = opts.length - 1;
        while (last > 0 && opts[last].disabled) last--;
        const r = st.resolve;
        this.st = null;
        this.audio.sfx("cancel");
        r(last);
      }
    }
  }

  draw(g: Ctx2D) {
    // 目的バー
    if (this.objectiveText) {
      g.fillStyle = "rgba(5,5,10,0.72)";
      g.fillRect(0, 0, W, 15);
      text(g, `目的:${this.objectiveText}`, 6, 3, { size: 9, color: "#e8e8ee" });
    }
    // 熟れ度ゲージ
    if (this.gaugeV !== null) {
      const v = Math.max(0, Math.min(100, this.gaugeV));
      const x = W - 16, y = 22, h = 56;
      text(g, "空の", x - 6, y - 10, { size: 7, color: this.gaugeV >= 70 ? "#ff6a6a" : "#cfcfd6" });
      text(g, "熟れ度", x - 6, y - 2, { size: 7, color: this.gaugeV >= 70 ? "#ff6a6a" : "#cfcfd6" });
      g.fillStyle = "rgba(5,5,10,0.6)";
      g.fillRect(x, y + 8, 8, h);
      const hh = (h - 4) * (v / 100);
      const grad = g.createLinearGradient(0, y + h - 4 - hh, 0, y + h - 4);
      grad.addColorStop(0, v >= 70 ? "#ff3d3d" : "#ffd0a8");
      grad.addColorStop(1, "#8a1250");
      g.fillStyle = grad;
      g.fillRect(x + 2, y + 8 + (h - 4) - hh, 4, hh);
      if (v >= 70) {
        const p = 0.5 + Math.sin(performance.now() / 160) * 0.5;
        g.strokeStyle = `rgba(255,60,60,${0.4 + p * 0.6})`;
        g.lineWidth = 1.5;
        g.strokeRect(x - 1, y + 7, 10, h + 2);
        if (v >= 100) { /* 上限 */ }
      }
      g.strokeStyle = "#8e8e96";
      g.lineWidth = 1;
      g.strokeRect(x + 0.5, y + 8.5, 8, h);
      if (v >= 70 && v < 100) {
        text(g, "C:コール", x - 22, y + h + 12, { size: 7, color: "#ffb0b0" });
      }
    }
    // トースト(部屋名)
    if (this.toastState) {
      const remain = this.toastState.until - performance.now();
      if (remain <= 0) this.toastState = null;
      else {
        const a = Math.min(1, remain / 500);
        g.save();
        g.globalAlpha = a;
        g.fillStyle = "rgba(5,5,10,0.78)";
        g.fillRect(6, 20, this.toastState.text.length * 11 + 20, 18);
        text(g, this.toastState.text, 16, 24, { size: 11, color: "#f2f2f6" });
        g.restore();
      }
    }
    // メッセージウィンドウ
    const st = this.st;
    if (!st) return;
    if (st.type === "say") {
      const bx = 6, by = 184, bw = W - 12, bh = 50;
      const dreamy = this.g.stage.other;
      g.fillStyle = "rgba(6,6,12,0.9)";
      g.fillRect(bx, by, bw, bh);
      const grd = g.createLinearGradient(bx, 0, bx + bw, 0);
      if (dreamy) {
        grd.addColorStop(0, "#ff5a9e"); grd.addColorStop(0.5, "#52ff6a"); grd.addColorStop(1, "#31b8ff");
      } else {
        grd.addColorStop(0, "#f2f2f6"); grd.addColorStop(0.5, "#c9c9d0"); grd.addColorStop(1, "#f2f2f6");
      }
      g.strokeStyle = grd;
      g.lineWidth = 2;
      g.strokeRect(bx + 1, by + 1, bw - 2, bh - 2);
      // 名前
      if (st.name) {
        g.fillStyle = "rgba(6,6,12,0.95)";
        const nw = st.name.length * 12 + 14;
        g.fillRect(bx + 8, by - 10, nw, 15);
        g.strokeRect(bx + 8, by - 10, nw, 15);
        if (st.mike) rainbowText(g, st.name, bx + 15, by - 8, 10, performance.now() / 300);
        else text(g, st.name, bx + 15, by - 8, { size: 10, color: "#ffe9c9" });
      }
      // 本文
      const lines = st.pages[st.page];
      let shown = st.shown;
      for (let li = 0; li < lines.length; li++) {
        const line = lines[li];
        const disp = line.slice(0, Math.max(0, shown));
        shown -= line.length;
        if (st.mike) rainbowText(g, disp, bx + 10, by + 9 + li * 13, 11, performance.now() / 260);
        else text(g, disp, bx + 10, by + 9 + li * 13, { size: 11 });
      }
      // 待機カーソル
      const pageText = lines.join("");
      if (st.shown >= pageText.length) {
        const bob = Math.sin(performance.now() / 200) * 2;
        g.fillStyle = "#f2f2f6";
        g.beginPath();
        g.moveTo(bx + bw / 2 - 4, by + bh - 7 + bob);
        g.lineTo(bx + bw / 2 + 4, by + bh - 7 + bob);
        g.lineTo(bx + bw / 2, by + bh - 2 + bob);
        g.closePath();
        g.fill();
      }
    } else {
      // 選択肢
      const bw = 180;
      const bh = st.opts.length * 15 + (st.title ? 16 : 8);
      const bx = W - bw - 8, by = 178 - bh;
      g.fillStyle = "rgba(6,6,12,0.93)";
      g.fillRect(bx, by, bw, bh);
      g.strokeStyle = "#e8e8ee";
      g.lineWidth = 1.5;
      g.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
      let yy = by + 5;
      if (st.title) { text(g, st.title, bx + 10, by + 4, { size: 10, color: "#ffe9c9" }); yy += 16; }
      st.opts.forEach((o, i) => {
        const sel = i === st.index;
        if (sel) {
          g.fillStyle = "rgba(240,240,250,0.14)";
          g.fillRect(bx + 4, yy - 1, bw - 8, 13);
          text(g, "▶", bx + 8, yy, { size: 9, color: "#f2f2f6" });
        } else text(g, "　", bx + 8, yy, { size: 9 });
        text(g, o.label, bx + 20, yy, { size: 10, color: o.disabled ? "#6a6a72" : "#f2f2f6" });
        if (o.disabled && o.note && sel) {
          text(g, `(${o.note})`, bx + 20, yy + 11, { size: 7, color: "#8a8a92" });
        }
        yy += 15;
      });
    }
  }
}

// ---------------- FX ----------------
class FXImpl implements FX {
  private fadeA = 0;
  private fadeColor = "#000000";
  private fadeAnim: { from: number; to: number; dur: number; t: number; resolve: () => void } | null = null;
  private bleedAnim: { t: number; dur: number; mid: () => void; fired: boolean; resolve: () => void } | null = null;
  private shakeUntil = 0; private shakeAmp = 0;
  private flashColor = "#ffffff"; private flashUntil = 0; private flashDur = 1;
  private satV = -1;

  fadeOut(color: string, ms: number): Promise<void> {
    return new Promise((r) => {
      this.fadeColor = color;
      this.fadeAnim = { from: this.fadeA, to: 1, dur: ms / 1000, t: 0, resolve: r };
    });
  }
  fadeIn(ms: number): Promise<void> {
    return new Promise((r) => {
      this.fadeAnim = { from: this.fadeA, to: 0, dur: ms / 1000, t: 0, resolve: r };
    });
  }
  bleed(mid: () => void, ms = 1700): Promise<void> {
    return new Promise((r) => {
      this.bleedAnim = { t: 0, dur: ms / 1000, mid, fired: false, resolve: r };
    });
  }
  shake(amp: number, ms: number) { this.shakeAmp = amp; this.shakeUntil = performance.now() + ms; }
  flash(color: string, ms: number) { this.flashColor = color; this.flashUntil = performance.now() + ms; this.flashDur = ms; }
  sat(v: number) { this.satV = v; }

  update(dt: number) {
    if (this.fadeAnim) {
      const a = this.fadeAnim;
      a.t += dt;
      const k = Math.min(1, a.t / a.dur);
      this.fadeA = a.from + (a.to - a.from) * k;
      if (k >= 1) { a.resolve(); this.fadeAnim = null; }
    }
    if (this.bleedAnim) {
      const b = this.bleedAnim;
      b.t += dt;
      if (!b.fired && b.t / b.dur >= 0.5) { b.fired = true; b.mid(); }
      if (b.t >= b.dur) { b.resolve(); this.bleedAnim = null; }
    }
  }
  shakeOffset(): [number, number] {
    if (performance.now() < this.shakeUntil) {
      return [(Math.random() - 0.5) * this.shakeAmp * 2, (Math.random() - 0.5) * this.shakeAmp * 2];
    }
    return [0, 0];
  }
  filter(): string {
    return this.satV >= 0 ? `saturate(${this.satV}%)` : "none";
  }
  draw(g: Ctx2D, scale: number) {
    // 色のにじみ(向こう側への移行演出)
    if (this.bleedAnim) {
      const b = this.bleedAnim;
      const k = b.t / b.dur;
      const ease = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      g.save();
      g.scale(scale, scale);
      g.globalCompositeOperation = "lighter";
      const R = ease * 260;
      const seeds = [12, 87, 41, 63, 29, 95, 54, 7, 71, 38];
      for (let i = 0; i < 10; i++) {
        const sx = 160 + Math.cos(i * 2.3) * (40 + seeds[i]);
        const sy = 120 + Math.sin(i * 1.7) * (30 + ((seeds[i] * 7) % 60));
        const rr = Math.max(0, R - seeds[i] * 1.1);
        if (rr <= 0) continue;
        const grad = g.createRadialGradient(sx, sy, 0, sx, sy, rr);
        const c = RAINBOW[i % RAINBOW.length];
        grad.addColorStop(0, c);
        grad.addColorStop(1, "rgba(0,0,0,0)");
        g.fillStyle = grad;
        g.globalAlpha = 0.55;
        g.beginPath();
        g.arc(sx, sy, rr, 0, Math.PI * 2);
        g.fill();
      }
      g.globalAlpha = 1;
      g.globalCompositeOperation = "source-over";
      // 白い輪郭
      g.strokeStyle = `rgba(255,255,255,${0.6 * (1 - k)})`;
      g.lineWidth = 3;
      g.beginPath();
      g.arc(160, 120, R * 1.15, 0, Math.PI * 2);
      g.stroke();
      g.restore();
    }
    // フラッシュ
    const fl = this.flashUntil - performance.now();
    if (fl > 0) {
      g.save();
      g.globalAlpha = (fl / this.flashDur) * 0.9;
      g.fillStyle = this.flashColor;
      g.fillRect(0, 0, W * scale, H * scale);
      g.restore();
    }
    // フェード
    if (this.fadeA > 0.001) {
      g.save();
      g.globalAlpha = this.fadeA;
      g.fillStyle = this.fadeColor;
      g.fillRect(0, 0, W * scale, H * scale);
      g.restore();
    }
  }
}

// ---------------- ステージ(VN用背景層) ----------------
class StageImpl implements Stage {
  show = false;
  bg = "real_hall";
  other = false;
  dark = 0;
  chars: StageChar[] = [];
  props: string[] = [];
  setBg(bg: string, other = false) { this.bg = bg; this.other = other; }
  setChars(list: StageChar[]) { this.chars = list; }
  setProps(list: string[]) { this.props = list; }
  reset() { this.show = false; this.chars = []; this.props = []; this.other = false; this.dark = 0; }
  draw(g: Ctx2D, t: number) {
    drawBG(g, this.bg, t);
    // プロップ:面会室の机の上の赤い首輪(モノクロ世界の赤)
    if (this.props.includes("collar")) {
      g.save();
      g.strokeStyle = this.other ? "#ff3d5e" : "#a01218";
      g.lineWidth = 4;
      g.beginPath();
      g.arc(160, 141, 13, 0, Math.PI * 2);
      g.stroke();
      g.fillStyle = this.other ? "#ffd93a" : "#8e8e96";
      g.beginPath();
      g.arc(160, 155, 4, 0, Math.PI * 2);
      g.fill();
      g.restore();
    }
    if (this.props.includes("toast")) {
      g.save();
      g.fillStyle = this.other ? "#ffdf5e" : "#c9c9ce";
      g.beginPath();
      g.roundRect(140, 128, 44, 24, 3);
      g.fill();
      g.fillStyle = "rgba(255,255,255,0.5)";
      g.fillRect(146, 132, 32, 3);
      g.restore();
    }
    if (this.props.includes("letters")) {
      g.save();
      g.fillStyle = "#f2f2f4";
      for (let i = 0; i < 7; i++) g.fillRect(52 + i * 12, 102, 10, 6);
      g.restore();
    }
    // キャラ
    const n = this.chars.length;
    this.chars.forEach((c, i) => {
      const cx = c.x ?? (n === 1 ? 160 : 90 + (140 / Math.max(1, n - 1)) * i);
      if (c.id === "mike") {
        drawMike(g, cx - 16, 168, t, 1.4, c.alpha ?? 1);
      } else {
        drawCharLarge(g, c.id, cx, 196, c.alpha ?? 1);
      }
    });
    if (this.dark > 0) {
      g.fillStyle = `rgba(2,2,10,${this.dark})`;
      g.fillRect(0, 0, W, H);
    }
    if (this.props.includes("windowlight")) {
      const grad = g.createRadialGradient(250, 40, 6, 250, 40, 150);
      grad.addColorStop(0, "rgba(255,255,240,0.5)");
      grad.addColorStop(1, "rgba(255,255,240,0)");
      g.fillStyle = grad;
      g.fillRect(0, 0, W, H);
    }
  }
}

// ---------------- タイトル画面 ----------------
class TitleScene implements Scene {
  done = false;
  sel = "new";
  private index = 0;
  private items: { id: string; label: string }[] = [];
  private t = 0;
  constructor(private G: Game) {
    this.items.push({ id: "new", label: "はじめから" });
    const sv = G.save as SaveImpl;
    if (sv.hasRun()) this.items.push({ id: "continue", label: "つづきから" });
    if (G.save.d.unlockedCall) this.items.push({ id: "callitem", label: "ナースコールを、押す" });
  }
  enter() {
    this.G.stage.show = true;
    this.G.stage.setBg("title", false);
    this.G.stage.setChars([]);
    this.G.stage.dark = 0;
    this.G.audio.bgm("title", 800);
  }
  exit() { this.G.ui.objective(null); this.G.ui.setGauge(null); }
  update(dt: number) {
    this.t += dt;
    if (this.G.input.consume("up")) { this.index = (this.index - 1 + this.items.length) % this.items.length; this.G.audio.sfx("cursor"); }
    if (this.G.input.consume("down")) { this.index = (this.index + 1) % this.items.length; this.G.audio.sfx("cursor"); }
    if (this.G.input.consume("z")) {
      this.sel = this.items[this.index].id;
      this.done = true;
      this.G.audio.sfx("confirm");
    }
  }
  draw(g: Ctx2D) {
    g.fillStyle = "rgba(4,4,10,0.25)";
    g.fillRect(0, 0, W, H);
    // ロゴの滲み
    const p = 0.5 + Math.sin(this.t * 1.4) * 0.12;
    g.save();
    g.globalAlpha = 0.75;
    const grad = g.createLinearGradient(100, 40, 220, 100);
    grad.addColorStop(0, RAINBOW[0]); grad.addColorStop(0.5, RAINBOW[3]); grad.addColorStop(1, RAINBOW[5]);
    g.shadowColor = "rgba(255,255,255,0.7)";
    g.shadowBlur = 26 * p + 8;
    g.fillStyle = grad;
    g.font = `700 64px ${FONT}`;
    g.textAlign = "center";
    g.fillText("いろ", 160, 108);
    g.restore();
    // 白いサインリング
    g.save();
    g.globalAlpha = 0.4 + Math.sin(this.t * 0.8) * 0.15;
    g.strokeStyle = "#f2f2f6";
    g.lineWidth = 1;
    g.beginPath();
    g.ellipse(160, 90, 70, 34, 0, 0, Math.PI * 2);
    g.stroke();
    g.restore();
    // メニュー
    g.font = `13px ${FONT}`;
    this.items.forEach((it, i) => {
      const y = 152 + i * 22;
      const sel = i === this.index;
      g.fillStyle = sel ? "#ffffff" : "rgba(220,220,230,0.55)";
      g.textAlign = "center";
      g.fillText(`${sel ? "▶ " : "　"}${it.label}`, 160, y);
    });
    g.font = `8px ${FONT}`;
    g.fillStyle = "rgba(210,210,220,0.5)";
    g.fillText("この作品には、精神疾患と、家族の死を扱う場面があります。", 160, 226);
    g.fillText("矢印キー:えらぶ / Z:決定", 160, 216);
  }
  drawHud() {}
}

// ---------------- ブート ----------------
export function initGame(root: HTMLElement): () => void {
  root.innerHTML = "";
  const wrap = document.createElement("div");
  wrap.style.cssText = "display:flex;flex-direction:column;align-items:center;gap:6px;";
  root.appendChild(wrap);

  const canvas = document.createElement("canvas");
  canvas.style.cssText = "background:#000;image-rendering:pixelated;box-shadow:0 0 60px rgba(120,80,180,0.25);border-radius:4px;";
  wrap.appendChild(canvas);

  // バッファ(内部解像度 320x240)
  const buf = document.createElement("canvas");
  buf.width = W; buf.height = H;
  const bg = buf.getContext("2d")!;
  bg.imageSmoothingEnabled = false;
  const scratch = document.createElement("canvas");
  scratch.width = W; scratch.height = H;
  const sg = scratch.getContext("2d")!;
  sg.imageSmoothingEnabled = false;

  const dctx = canvas.getContext("2d")!;

  // 入力
  let disposed = false;
  const input = new InputImpl(() => audioSys.unlock());

  // ゲームコンテキスト
  const save = new SaveImpl();
  save.load();
  const stage = new StageImpl();
  const fx = new FXImpl();

  let active: { scene: Scene; resolve: (s: Scene) => void } | null = null;

  const G: Game = {
    W, H,
    input, assets: new AssetsImpl(), audio: audioSys, save, ui: null as unknown as UI, fx, stage,
    scenes: {
      run<T extends Scene>(s: T): Promise<T> {
        return new Promise<T>((res) => {
          active = { scene: s, resolve: (sc) => res(sc as T) };
          s.enter?.();
        });
      },
    },
    now: 0,
  };
  const ui = new UIImpl(G, input, audioSys);
  G.ui = ui;

  // 画面下の操作ボタン
  const padArea = document.createElement("div");
  padArea.style.cssText = "display:flex;justify-content:space-between;width:100%;max-width:560px;padding:4px 6px;box-sizing:border-box;";
  wrap.appendChild(padArea);
  const mkBtn = (label: string, sub = false) => {
    const b = document.createElement("button");
    b.textContent = label;
    b.style.cssText = `${sub ? "width:40px;height:40px;font-size:12px;" : "width:52px;height:52px;font-size:16px;"}border-radius:${sub ? "12px" : "50%"};border:1.5px solid rgba(240,240,250,0.35);background:rgba(20,20,30,0.6);color:#e8e8ee;touch-action:none;` +
      "display:flex;align-items:center;justify-content:center;cursor:pointer;";
    return b;
  };
  const dpad = document.createElement("div");
  dpad.style.cssText = "display:grid;grid-template-columns:repeat(3,52px);grid-template-rows:repeat(3,52px);gap:2px;";
  padArea.appendChild(dpad);
  const cells: (HTMLElement | null)[] = [];
  const upB = mkBtn("▲"), lfB = mkBtn("◀"), rtB = mkBtn("▶"), dnB = mkBtn("▼");
  cells.push(null, upB, null, lfB, null, rtB, null, dnB, null);
  for (let i = 0; i < 9; i++) {
    const c = document.createElement("div");
    const el = cells[i];
    if (el) c.appendChild(el);
    dpad.appendChild(c);
  }
  input.bindButton(upB, "up"); input.bindButton(lfB, "left");
  input.bindButton(rtB, "right"); input.bindButton(dnB, "down");
  const acts = document.createElement("div");
  acts.style.cssText = "display:flex;align-items:flex-end;gap:8px;padding-bottom:2px;";
  const cB = mkBtn("C", true), xB = mkBtn("X"), zB = mkBtn("Z");
  cB.title = "ナースコール"; xB.title = "キャンセル"; zB.title = "決定";
  acts.appendChild(cB); acts.appendChild(xB); acts.appendChild(zB);
  padArea.appendChild(acts);
  input.bindButton(cB, "c"); input.bindButton(xB, "x"); input.bindButton(zB, "z");
  // キャンバスタップ = Z
  canvas.addEventListener("pointerdown", (e) => { e.preventDefault(); input.tap("z"); });

  // リサイズ(整数倍)
  const applyScale = () => {
    const availH = Math.max(220, window.innerHeight - 190);
    const availW = window.innerWidth - 16;
    let s = Math.max(1, Math.floor(Math.min(availW / W, availH / H)));
    if (availW < W || availH < H) {
      // 小さい画面は縮小(小数)を許容
      s = Math.min(availW / W, availH / H);
      canvas.width = Math.round(W * s);
      canvas.height = Math.round(H * s);
    } else {
      canvas.width = W * s;
      canvas.height = H * s;
    }
    canvas.style.width = `${canvas.width}px`;
    canvas.style.height = `${canvas.height}px`;
    dctx.imageSmoothingEnabled = false;
  };
  applyScale();
  window.addEventListener("resize", applyScale);

  // メインループ
  let last = performance.now();
  let raf = 0;
  const loop = () => {
    if (disposed) return;
    const nowMs = performance.now();
    let dt = (nowMs - last) / 1000;
    last = nowMs;
    if (dt > 0.1) dt = 0.1;
    G.now = nowMs;

    fx.update(dt);
    ui.update(dt);
    if (active) {
      active.scene.update(dt);
    }

    // --- 描画 ---
    bg.setTransform(1, 0, 0, 1, 0, 0);
    bg.globalAlpha = 1;
    bg.fillStyle = "#000";
    bg.fillRect(0, 0, W, H);
    const tSec = nowMs / 1000;
    if (stage.show) {
      sg.setTransform(1, 0, 0, 1, 0, 0);
      sg.clearRect(0, 0, W, H);
      stage.draw(sg, tSec);
      if (stage.other) {
        // 向こう側:行ごとの歪み
        const amp = 2.2;
        for (let y = 0; y < H; y += 2) {
          const off = Math.round(Math.sin(y * 0.09 + tSec * 2.4) * amp);
          bg.drawImage(scratch, 0, y, W, 2, off, y, W, 2);
        }
      } else {
        bg.drawImage(scratch, 0, 0);
      }
    }
    if (active) {
      active.scene.draw(bg);
    }

    // コンポジット
    const s = canvas.width / W;
    dctx.setTransform(1, 0, 0, 1, 0, 0);
    dctx.clearRect(0, 0, canvas.width, canvas.height);
    const [sx, sy] = fx.shakeOffset();
    try { dctx.filter = fx.filter(); } catch { /* 非対応 */ }
    dctx.drawImage(buf, Math.round(sx * s), Math.round(sy * s), canvas.width, canvas.height);
    try { dctx.filter = "none"; } catch { /* */ }

    // HUD(くっきり文字)
    dctx.setTransform(s, 0, 0, s, 0, 0);
    if (active && active.scene.drawHud) active.scene.drawHud(dctx);
    ui.draw(dctx);
    dctx.setTransform(1, 0, 0, 1, 0, 0);
    fx.draw(dctx, s);

    // シーン完了
    if (active && active.scene.done) {
      const sc = active.scene;
      sc.exit?.();
      const r = active.resolve;
      active = null;
      r(sc);
    }
    input.post();
    raf = requestAnimationFrame(loop);
  };

  // 起動
  const assets = G.assets as AssetsImpl;
  let flowStarted = false;
  (async () => {
    // 簡易ローディング表示
    dctx.setTransform(1, 0, 0, 1, 0, 0);
    dctx.fillStyle = "#000";
    dctx.fillRect(0, 0, canvas.width, canvas.height);
    await assets.loadAll((n, total) => {
      dctx.fillStyle = "#000";
      dctx.fillRect(0, 0, canvas.width, canvas.height);
      dctx.fillStyle = "#888";
      dctx.font = "10px sans-serif";
      dctx.textAlign = "center";
      dctx.fillText(`よみこみちゅう… ${n}/${total}`, canvas.width / 2, canvas.height / 2);
    });
    if (disposed || flowStarted) return;
    flowStarted = true;
    raf = requestAnimationFrame(loop);
    let guard = 0;
    while (!disposed && guard++ < 999) {
      const t = await G.scenes.run(new TitleScene(G));
      if (disposed) return;
      await fx.fadeOut("#000000", 500);
      G.stage.show = false;
      if (t.sel === "new") {
        G.save.wipeRun();
        await story(G, "prologue");
      } else if (t.sel === "continue") {
        await story(G, G.save.d.checkpoint || "prologue");
      } else if (t.sel === "callitem") {
        await nurseCallMini(G);
      }
      await fx.fadeIn(600);
    }
  })().catch((e) => {
    console.error("[いろ] story error", e);
  });

  return () => {
    disposed = true;
    cancelAnimationFrame(raf);
    window.removeEventListener("resize", applyScale);
    root.innerHTML = "";
  };
}

export type { Game };
export { text, drawBG, drawCharLarge, drawMike, rainbowText, TitleScene };
