// ============================================================
// いろ — 探索シーン(見下ろし視点・マップ移動・調べ・ナースコール)
// ============================================================
import type { Ctx2D, ExploreAPI, ExploreConfig, ExploreMarker, FaceDir, Game, Scene } from "./types";
import { MAPS, TILE, solid, tileAt, type GameMap } from "./maps";
import { CHARPAL, drawMike, drawPerson, drawTiles, text, FONT } from "./art";
import { HANA_DEFAULT } from "./story";

const TIME_TINT: Record<string, string> = {
  day: "rgba(0,0,0,0)",
  evening: "rgba(40,16,50,0.18)",
  night: "rgba(4,4,18,0.42)",
};

export class ExploreScene implements Scene, ExploreAPI {
  done = false;
  ripeness = 0;
  allowCall = false;

  private map: GameMap;
  private px: number; // px座標(中心)
  private py: number;
  private dir: FaceDir;
  private frame = 0;
  private animT = 0;
  private camX = 0;
  private busy = false;
  private finishing = false;
  private ripeFullFired = false;
  private callFlashT = 0;
  private markers: ExploreMarker[];
  private stepT = 0;
  private mikeT = 0;

  constructor(private G: Game, private cfg: ExploreConfig) {
    this.map = MAPS[cfg.startMap];
    this.px = cfg.spawn[0] * TILE + TILE / 2;
    this.py = cfg.spawn[1] * TILE + TILE / 2;
    this.dir = cfg.dir ?? "down";
    this.markers = cfg.markers;
    this.ripeness = cfg.ripeness ?? 0;
    this.allowCall = cfg.allowCall ?? false;
  }

  enter() {
    this.G.ui.objective(this.cfg.objective);
    if (this.cfg.ripeness !== null) this.G.ui.setGauge(this.ripeness);
    this.G.stage.show = false;
    this.G.ui.toast(`—— ${this.map.name}`);
    this.G.audio.sfx("door");
    this.G.audio.bgm(this.cfg.side === "other" ? "other" : this.cfg.time === "night" ? "real" : "real", 600);
  }
  exit() {
    this.G.ui.objective(null);
    this.G.ui.setGauge(null);
  }

  // --- ExploreAPI ---
  setObjective(t: string) { this.G.ui.objective(t); }
  setMarkers(m: ExploreMarker[]) { this.markers = m; }
  setRipeRate(_r: number) { /* ripeRate は cfg 経由 */ }
  callFlash() { this.callFlashT = 1; }
  finish() {
    if (this.finishing) return;
    this.finishing = true;
    void (async () => {
      await this.G.fx.fadeOut("#000000", 450);
      this.done = true;
    })();
  }

  private collides(nx: number, ny: number): boolean {
    // 当たり判定(中心±4pxの矩形)
    const pts = [[-4, -3], [4, -3], [-4, 5], [4, 5]];
    for (const [ox, oy] of pts) {
      const tx = Math.floor((nx + ox) / TILE);
      const ty = Math.floor((ny + oy) / TILE);
      if (solid(tileAt(this.map, tx, ty))) return true;
    }
    // NPC
    for (const npc of this.map.npcs) {
      const nx2 = npc.x * TILE + TILE / 2;
      const ny2 = npc.y * TILE + TILE / 2;
      if (Math.abs(nx - nx2) < 10 && Math.abs(ny - ny2) < 12) return true;
    }
    return false;
  }

  private async doDoor() {
    const tx = Math.floor(this.px / TILE);
    const ty = Math.floor(this.py / TILE);
    const d = this.map.doors.find((dd) => dd.x === tx && dd.y === ty);
    if (!d) return;
    this.busy = true;
    this.G.audio.sfx("door");
    await this.G.fx.fadeOut("#000000", 280);
    this.map = MAPS[d.to];
    this.px = d.tx * TILE + TILE / 2;
    this.py = d.ty * TILE + TILE / 2;
    this.dir = d.dir ?? "down";
    this.G.ui.toast(`—— ${this.map.name}`);
    await this.G.fx.fadeIn(280);
    this.busy = false;
  }

  private facingTile(): [number, number] {
    const tx = Math.floor(this.px / TILE);
    const ty = Math.floor(this.py / TILE);
    if (this.dir === "up") return [tx, ty - 1];
    if (this.dir === "down") return [tx, ty + 1];
    if (this.dir === "left") return [tx - 1, ty];
    return [tx + 1, ty];
  }

  private async examine() {
    // NPC 優先
    const [fx2, fy2] = this.facingTile();
    for (const npc of this.map.npcs) {
      if (npc.x === fx2 && npc.y === fy2) {
        this.busy = true;
        const lines = this.cfg.hanaLines ?? HANA_DEFAULT;
        await this.G.ui.lines(lines);
        this.busy = false;
        return;
      }
    }
    for (const p of this.map.props) {
      const w = p.w ?? 1, h = p.h ?? 1;
      if (fx2 >= p.x && fx2 < p.x + w && fy2 >= p.y && fy2 < p.y + h) {
        this.busy = true;
        if (this.cfg.onExamine) {
          await this.cfg.onExamine(p.id, this);
        } else if (p.flavor) {
          await this.G.ui.lines(p.flavor);
        }
        this.busy = false;
        return;
      }
    }
  }

  update(dt: number) {
    if (this.done) return;
    this.mikeT += dt;
    if (this.busy || this.G.ui.busy() || this.finishing) return;

    // 熟れ度の上昇
    if (this.cfg.ripeness !== null && this.cfg.ripeRate) {
      this.ripeness = Math.min(110, this.ripeness + this.cfg.ripeRate * dt);
      this.G.ui.setGauge(Math.min(100, this.ripeness));
      if (this.ripeness >= 100 && !this.ripeFullFired && this.cfg.onRipeFull) {
        this.ripeFullFired = true;
        this.busy = true;
        void (async () => {
          await this.cfg.onRipeFull!(this);
          this.busy = false;
        })();
        return;
      }
    }

    // C:ナースコール
    if (this.allowCall && this.G.input.consume("c")) {
      if (this.ripeness >= 70 && this.cfg.onCall) {
        this.busy = true;
        this.G.audio.sfx("call");
        this.callFlashT = 1;
        void (async () => {
          try {
            const fin = await this.cfg.onCall!(this);
            if (fin && !this.finishing) this.finish();
          } finally {
            this.busy = false;
          }
        })();
        return;
      } else {
        this.busy = true;
        this.G.audio.sfx("call");
        void (async () => {
          await this.G.ui.narr(this.ripeness >= 40 ? "……今は、まだ言える。まだ、自分でいられる。" : "ナースコール。いつでも、誰かにつながっている。");
          this.busy = false;
        })();
        return;
      }
    }

    // Z:調べる
    if (this.G.input.consume("z")) {
      void this.examine();
      return;
    }

    // 移動
    let mx = 0, my = 0;
    if (this.G.input.held("up")) my -= 1;
    if (this.G.input.held("down")) my += 1;
    if (this.G.input.held("left")) mx -= 1;
    if (this.G.input.held("right")) mx += 1;
    if (mx !== 0 && my !== 0) { mx *= 0.707; my *= 0.707; }
    if (mx !== 0 || my !== 0) {
      const sp = 64 * dt;
      const nx = this.px + mx * sp;
      const ny = this.py + my * sp;
      if (!this.collides(nx, this.py)) this.px = nx;
      if (!this.collides(this.px, ny)) this.py = ny;
      if (Math.abs(mx) > Math.abs(my)) this.dir = mx > 0 ? "right" : "left";
      else if (my !== 0) this.dir = my > 0 ? "down" : "up";
      this.animT += dt;
      if (this.animT > 0.18) {
        this.animT = 0;
        this.frame = this.frame === 1 ? 2 : 1;
        this.stepT += 1;
        if (this.stepT % 2 === 0) this.G.audio.sfx("step");
      }
      // ドア判定
      void this.doDoor();
      // マーカー判定
      for (const mk of this.markers) {
        const mxp = mk.x * TILE + TILE / 2;
        const myp = mk.y * TILE + TILE / 2;
        if (mk.map === this.map.id && Math.abs(this.px - mxp) < 11 && Math.abs(this.py - myp) < 13) {
          this.busy = true;
          void (async () => {
            try {
              const fin = this.cfg.onMarker ? await this.cfg.onMarker(mk.id, this) : false;
              if (fin && !this.finishing) this.finish();
            } finally {
              this.busy = false;
            }
          })();
          break;
        }
      }
    } else {
      this.frame = 0;
      this.animT = 0.1;
    }
  }

  draw(g: Ctx2D) {
    const mapW = this.map.w * TILE;
    const mapH = this.map.h * TILE;
    // カメラ(廊下のみ追従)
    if (mapW > 320) {
      this.camX = Math.max(0, Math.min(mapW - 320, this.px - 160));
    } else {
      this.camX = (mapW - 320) / 2;
    }
    const camY = mapH > 240 ? Math.max(0, Math.min(mapH - 240, this.py - 120)) : (mapH - 240) / 2;
    const cx = Math.round(this.camX), cy = Math.round(camY);

    g.fillStyle = "#000";
    g.fillRect(0, 0, 320, 240);
    drawTiles(g, this.map, this.cfg.side, cx, cy);

    // マーカー(目的地点の光)
    const t = this.mikeT;
    for (const mk of this.markers) {
      if (mk.map !== this.map.id) continue;
      const mx = mk.x * TILE + TILE / 2 - cx;
      const my = mk.y * TILE + TILE / 2 - cy;
      const p = 0.5 + Math.sin(t * 4) * 0.5;
      g.save();
      g.globalAlpha = 0.5 + p * 0.4;
      g.fillStyle = this.cfg.side === "other" ? "#52ff6a" : "#f2f2f6";
      g.beginPath();
      g.moveTo(mx, my - 10 - p * 3);
      g.lineTo(mx + 5, my - 4 - p * 3);
      g.lineTo(mx, my + 2 - p * 3);
      g.lineTo(mx - 5, my - 4 - p * 3);
      g.closePath();
      g.fill();
      g.restore();
    }

    // キャラ描画順(Y順)
    const drawList: { y: number; fn: () => void }[] = [];
    const side = this.cfg.side;
    const pal = side === "other" ? CHARPAL.mio_other : CHARPAL.mio_real;
    for (const npc of this.map.npcs) {
      const nx = npc.x * TILE - cx;
      const ny = npc.y * TILE + TILE / 2 - cy;
      drawList.push({
        y: ny,
        fn: () => {
          drawPerson(g, nx, ny - 22 + 8, { ...CHARPAL.hana, frame: Math.sin(t * 2) > 0.9 ? 1 : 0, dir: "down" });
        },
      });
    }
    const pxd = Math.round(this.px - 8 - cx), pyd = Math.round(this.py - 22 - cy);
    drawList.push({
      y: this.py - cy,
      fn: () => drawPerson(g, pxd, pyd, { ...pal, frame: this.frame, dir: this.dir }),
    });
    if (side === "other") {
      drawList.push({
        y: this.py - cy + 2,
        fn: () => drawMike(g, pxd - 20 + Math.sin(t * 3) * 2, pyd + 8, t, 1, 0.95),
      });
    }
    drawList.sort((a, b) => a.y - b.y);
    for (const d of drawList) d.fn();

    // 向こう側の揺らぎ & 粒子
    if (side === "other") {
      for (let i = 0; i < 14; i++) {
        const fx2 = (i * 67 + t * 18 * ((i % 3) + 1)) % 340 - 10;
        const fy2 = (i * 91 + Math.sin(t + i) * 20) % 240;
        g.fillStyle = ["#ff5a9e", "#52ff6a", "#31b8ff", "#ffe14d"][i % 4];
        g.globalAlpha = 0.25 + 0.2 * Math.sin(t * 3 + i);
        g.fillRect(fx2, fy2, 2, 2);
      }
      g.globalAlpha = 1;
    }

    // 時間帯フィルタ
    const tint = TIME_TINT[this.cfg.time ?? "day"];
    if (tint !== "rgba(0,0,0,0)") {
      g.fillStyle = tint;
      g.fillRect(0, 0, 320, 240);
    }

    // コールの光
    if (this.callFlashT > 0) {
      this.callFlashT -= 0.02;
      g.save();
      g.globalAlpha = Math.max(0, this.callFlashT) * 0.35;
      g.fillStyle = "#ffffff";
      g.fillRect(0, 0, 320, 240);
      g.restore();
    }

    // プレイヤー周辺の柔らかい光(夜)
    if (this.cfg.time === "night") {
      const grad = g.createRadialGradient(this.px - cx, this.py - cy, 6, this.px - cx, this.py - cy, 90);
      grad.addColorStop(0, "rgba(255,250,230,0")
      grad.addColorStop(0, "rgba(255,250,230,0.08)");
      grad.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grad;
      g.fillRect(0, 0, 320, 240);
    }
  }

  drawHud(g: Ctx2D) {
    if (this.allowCall) {
      g.save();
      g.font = `8px ${FONT}`;
      g.fillStyle = this.ripeness >= 70 ? "#ffb0b0" : "rgba(200,200,210,0.5)";
      g.textAlign = "right";
      g.fillText(this.ripeness >= 70 ? "Cキー:ナースコール(あいことば)" : "C:ナースコール", 316, 130);
      g.restore();
    }
    if (!this.G.ui.busy() && !this.busy) {
      g.save();
      g.font = `8px ${FONT}`;
      g.fillStyle = "rgba(200,200,210,0.45)";
      g.textAlign = "left";
      text(g, "矢印:移動  Z:調べる", 6, 226, { size: 8, color: "rgba(210,210,220,0.5)" });
      g.restore();
    }
  }
}
