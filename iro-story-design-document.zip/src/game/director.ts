// ============================================================
// いろ — ディレクター(章進行・分岐・エンディング・手紙・ミニイベント)
// ============================================================
import type { Ctx2D, ExploreAPI, Game, Scene } from "./types";
import {
  BATTLE_NAMES, CH1_AFTER_SPARE, CH1_NIGHT, CH2_AFTER_SPARE, CH2_INTRO, CH2_REAL,
  CH3_HIDE, CH3_MORNING, CH3_NIGHT, CH3_TAKE, CH4_PILLOW, CH4_WAKE, CH5_CLUE1,
  CH5_CLUE2, CH5_CLUE3, CH5_GET, CH5_MORNING, CH6_AFTER, CH7_ACCEPT, CH7_CALL_KAEDE,
  CH7_DAYS, CH7_MIKE, CH7_NOTICE, CH8_VISIT, CH8_WITCH_INTRO, CH9_ROOM, CREDIT_LINES,
  ENDINGS, HANA_WEEK, LETTERS, MIKE_WHISPERS, N, PROLOGUE, SPARE_NOTE_GATE, type EndingDef,
} from "./story";
import { BattleScene } from "./battle";
import { ExploreScene } from "./explore";
import { drawBG, rainbowText, text } from "./art";

function cp(G: Game, id: string) {
  G.save.d.checkpoint = id;
  G.save.commit();
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------------- エンディングシーン ----------------
class EndingScene implements Scene {
  done = false;
  private idx = 0;
  private t = 0;
  private pages: [string, string][];
  private phase: "page" | "hint" | "card" = "page";
  constructor(private G: Game, private def: EndingDef) {
    if (def.no === "true") {
      this.pages = def.pages.map((p, i) => [i <= 1 ? "entrance" : "grave", p] as [string, string]);
    } else {
      this.pages = def.pages.map((p) => [def.bg, p] as [string, string]);
    }
  }
  enter() {
    this.G.stage.show = false;
    this.G.audio.bgm(this.def.no === "true" ? "ending" : "bad", 900);
    this.G.ui.objective(null);
  }
  update(dt: number) {
    this.t += dt;
    if (this.t > 0.5 && this.G.input.consume("z")) {
      this.G.audio.sfx("confirm");
      if (this.phase === "page") {
        if (this.idx < this.pages.length - 1) {
          this.idx++;
          this.t = 0;
        } else {
          this.phase = this.def.no === "true" ? "card" : "hint";
          this.t = 0;
        }
      } else if (this.phase === "card" && this.t < 5) {
        this.t = 5;
      } else {
        this.done = true;
      }
    }
    if (this.phase === "card" && this.t > 7) this.done = true;
  }
  draw(g: Ctx2D) {
    if (this.phase === "card") {
      g.fillStyle = "#05050a";
      g.fillRect(0, 0, 320, 240);
      return;
    }
    const [bgId] = this.pages[this.idx];
    drawBG(g, bgId, this.t);
    // レターボックス
    g.fillStyle = "rgba(3,3,8,0.94)";
    g.fillRect(0, 0, 320, 46);
    g.fillRect(0, 176, 320, 64);
  }
  drawHud(g: Ctx2D) {
    const d = this.def;
    if (this.phase === "card") {
      const a = Math.min(1, (this.t - 1) / 1.6);
      rainbowText(g, "いろ", 132, 74, 42, this.t * 2);
      CREDIT_LINES.forEach((l, i) => {
        text(g, l, 160, 130 + i * 13, { size: 10, color: `rgba(230,230,240,${0.8 * a})`, align: "center" });
      });
      return;
    }
    const label = d.no === "true" ? `TRUE END ― 「${d.title}」` : `BAD END ${d.no} ― 「${d.title}」`;
    text(g, label, 160, 16, {
      size: 12,
      align: "center",
      color: d.no === "true" ? "#ffe9c9" : "#ff8a9a",
    });
    if (this.phase === "hint" && d.hint) {
      text(g, d.hint, 160, 108, { size: 12, align: "center", color: "#f2f2f6" });
      text(g, "Z:タイトルへ(関門から、やり直せます)", 160, 196, { size: 9, align: "center", color: "#9a9aa2" });
      return;
    }
    // ページ本文
    const line = this.pages[this.idx][1];
    text(g, line, 160, 194, { size: 10, align: "center", color: "#e8e8ee" });
    text(g, "Z▼", 296, 168, { size: 8, color: "#9a9aa2" });
  }
}

// ---------------- 手紙シーン ----------------
class LetterScene implements Scene {
  done = false;
  private t = 0;
  constructor(private G: Game, private no: number, private body: string) {}
  enter() {
    this.G.audio.sfx("confirm");
  }
  update(dt: number) {
    this.t += dt;
    if (this.t > 0.4 && this.G.input.consume("z")) {
      this.done = true;
      this.G.audio.sfx("text");
    }
  }
  draw(g: Ctx2D) {
    g.fillStyle = "rgba(4,4,10,0.55)";
    g.fillRect(0, 0, 320, 240);
    // 便箋
    g.save();
    g.translate(160, 120);
    g.rotate(Math.sin(this.no * 2.3) * 0.02);
    g.fillStyle = "#f2f0ea";
    g.fillRect(-120, -86, 240, 172);
    g.strokeStyle = "#c9c4b8";
    g.lineWidth = 2;
    g.strokeRect(-118, -84, 236, 168);
    g.fillStyle = "#e3dfd2";
    g.fillRect(-120, -86, 240, 14);
    g.restore();
  }
  drawHud(g: Ctx2D) {
    const a = Math.min(1, this.t / 0.35);
    g.save();
    g.globalAlpha = a;
    text(g, `${this.no + 1} / 7 通目`, 64, 40, { size: 9, color: "#8a8578" });
    const lines = this.body.split("\n");
    lines.forEach((l, i) => {
      if (i === 0) text(g, l, 54, 56, { size: 10, color: "#5a564c" });
      else text(g, l, 54, 56 + i * 13, { size: 9, color: "#3d3a32" });
    });
    text(g, "Z:とじる", 240, 200, { size: 8, color: "#8a8578" });
    g.restore();
  }
}

// ---------------- バッドエンド処理 ----------------
async function runEnding(G: Game, key: string): Promise<void> {
  const def = ENDINGS[key];
  if (typeof def.no === "number") {
    if (!G.save.d.seenBad.includes(def.no)) G.save.d.seenBad.push(def.no);
    if (def.no === 7) G.save.d.unlockedCall = true;
    G.save.commit();
  }
  await G.fx.fadeOut("#000000", 700);
  const p = G.scenes.run(new EndingScene(G, def));
  await sleep(60);
  await G.fx.fadeIn(600); // フェードをここで戻さないと画面が黒のまま
  await p;
  await G.fx.fadeOut("#000000", 400);
}

// ---------------- プロローグ ----------------
async function pPrologue(G: Game): Promise<boolean> {
  cp(G, "prologue");
  G.stage.show = true;
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_hall", false);
  G.audio.bgm("real", 1200);
  await G.fx.fadeIn(1400);
  await G.ui.lines(PROLOGUE.slice(0, 4));
  G.stage.setChars([{ id: "kaede", x: 168 }]);
  await G.ui.lines(PROLOGUE.slice(4, 8));
  G.stage.setChars([]);
  await G.ui.lines(PROLOGUE.slice(8));
  await G.fx.fadeOut("#000000", 900);
  return true;
}

// ---------------- 第1章 向こう側 ----------------
async function pCh1(G: Game): Promise<boolean> {
  cp(G, "ch1");
  G.stage.show = true;
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_room", false);
  G.stage.dark = 0.62;
  G.audio.bgm("real", 600);
  await G.fx.fadeIn(800);
  await sleep(400);
  // 色のにじみ → 向こう側
  G.audio.sfx("whiteout");
  await G.fx.bleed(() => {
    G.stage.setBg("other_hall", true);
    G.stage.dark = 0;
    G.audio.bgm("other", 400);
  });
  await G.ui.lines(CH1_NIGHT.slice(0, 3));
  G.stage.setChars([{ id: "mike", x: 170 }]);
  G.audio.sfx("nyaa");
  await G.ui.lines(CH1_NIGHT.slice(3));
  G.stage.setChars([]);
  const res = (await G.scenes.run(
    new BattleScene(G, {
      id: "gyorome",
      enemyName: BATTLE_NAMES.gyorome,
      canSpare: true,
      whispers: MIKE_WHISPERS.gyorome,
      intro: ["——目玉だらけの影「ギョロメ」が、あらわれた。", "ミケ「見られてるにゃ。……消すにゃ」"],
    })
  )).result;

  G.stage.show = true;
  if (res === "fought") {
    await G.ui.lines([[null, "影は、簡単に消えた。それでも——"], [null, "消しても、消しても、廊下の光は、目の形に見え続けた。"]]);
    await runEnding(G, "bad1");
    return false;
  }
  // 見逃した
  G.stage.setBg("other_hall", true);
  G.stage.setChars([{ id: "mike", x: 170 }]);
  await G.fx.fadeIn(500);
  await G.ui.lines(CH1_AFTER_SPARE.slice(0, 2));
  await G.fx.fadeOut("#000000", 800);
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_room", false);
  G.audio.bgm("real", 900);
  await G.fx.fadeIn(900);
  await G.ui.lines(CH1_AFTER_SPARE.slice(2));
  await G.fx.fadeOut("#000000", 700);
  return true;
}

// ---------------- 第2章 蜜の食堂 ----------------
async function pCh2(G: Game): Promise<boolean> {
  cp(G, "ch2");
  G.stage.show = true;
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("other_canteen", true);
  G.audio.bgm("other", 500);
  G.stage.setChars([{ id: "mike", x: 220 }]);
  await G.fx.fadeIn(700);
  await G.ui.lines(CH2_INTRO);
  G.stage.setChars([]);
  const res = (await G.scenes.run(
    new BattleScene(G, {
      id: "honey",
      enemyName: BATTLE_NAMES.honey,
      canSpare: true,
      whispers: MIKE_WHISPERS.honey,
      intro: ["——蜜をしたたらせる蜂の女王「ハニークイーン」が、あらわれた。", "ミケ「毒にゃ。食べちゃだめにゃ」"],
    })
  )).result;

  G.stage.show = true;
  if (res === "fought") {
    await G.ui.lines([[null, "女王は倒れた。澪は、あの匂いの正体を知らないまま——"]]);
    await runEnding(G, "bad2");
    return false;
  }
  G.stage.setBg("other_canteen", true);
  G.stage.setChars([{ id: "mike", x: 220 }]);
  await G.fx.fadeIn(500);
  await G.ui.lines(CH2_AFTER_SPARE);
  await G.fx.fadeOut("#000000", 800);
  G.stage.setBg("real_canteen", false);
  G.stage.setProps(["toast"]);
  G.stage.setChars([{ id: "staff_meal", x: 210 }]);
  G.audio.bgm("real", 900);
  await G.fx.fadeIn(800);
  await G.ui.lines(CH2_REAL);
  G.stage.setProps([]);
  G.stage.setChars([]);
  await G.fx.fadeOut("#000000", 800);
  return true;
}

// ---------------- 第3章 白い門番 ----------------
async function pCh3(G: Game): Promise<boolean> {
  cp(G, "ch3");
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_room", false);
  G.stage.setChars([{ id: "kaede", x: 170 }]);
  G.audio.bgm("real", 800);
  await G.fx.fadeIn(900);
  await G.ui.lines(CH3_MORNING);
  const sel = await G.ui.choice([
    { label: "錠剤を、舌の下に隠す" },
    { label: "錠剤を飲む" },
  ], "どうする?");
  if (sel === 0) {
    G.stage.setChars([{ id: "mike", x: 240 }]);
    await G.ui.lines(CH3_HIDE);
    await runEnding(G, "bad3");
    return false;
  }
  await G.ui.lines(CH3_TAKE);
  await G.fx.fadeOut("#000000", 900);
  // 夜 —— いつもより赤い世界
  G.stage.setChars([]);
  G.stage.setBg("real_room", false);
  G.stage.dark = 0.62;
  await G.fx.fadeIn(500);
  await sleep(300);
  G.audio.sfx("whiteout");
  await G.fx.bleed(() => {
    G.stage.setBg("other_hall", true);
    G.stage.dark = 0;
    G.audio.bgm("other", 400);
  });
  G.stage.setChars([{ id: "mike", x: 230 }]);
  await G.ui.lines(CH3_NIGHT);
  G.stage.setChars([]);
  const res = (await G.scenes.run(
    new BattleScene(G, {
      id: "gatekeepers",
      enemyName: BATTLE_NAMES.gatekeepers,
      canSpare: false,
      spareNote: SPARE_NOTE_GATE,
      whispers: MIKE_WHISPERS.gate,
      intro: ["——白い巨体が三つ。「白い門番」が、あらわれた。", "ミケ「聞いちゃだめにゃ。あれは呪文にゃ」"],
      midText: [
        { turn: 1, text: "……さ…………じょ……ぶ……" },
        { turn: 2, text: "澪さん! 澪さん、大丈夫、大丈夫だから!" },
      ],
    })
  )).result;
  void res;
  // 三本目を斬る → 画面は白く
  G.stage.show = true;
  G.stage.setBg("white", false);
  G.audio.sfx("whiteout");
  await G.fx.fadeOut("#ffffff", 300);
  await sleep(400);
  return true;
}

// ---------------- 第4章 色が褪せる ----------------
async function pCh4(G: Game): Promise<boolean> {
  cp(G, "ch4");
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_room_broken", false);
  G.audio.bgm("real", 1200);
  G.audio.sfx("crack");
  await G.fx.fadeIn(1400);
  await G.ui.lines(CH4_WAKE.slice(0, 8));
  G.stage.setChars([{ id: "kaede_wound", x: 150 }]);
  G.audio.sfx("whisper");
  await G.ui.lines(CH4_WAKE.slice(8));
  await G.fx.fadeOut("#000000", 1000);
  // 枕元のミケ
  G.stage.setChars([]);
  G.stage.setBg("real_room", false);
  G.stage.dark = 0.5;
  G.stage.setProps(["windowlight"]);
  await G.fx.fadeIn(700);
  G.stage.setChars([{ id: "mike", x: 236 }]);
  await G.ui.lines(CH4_PILLOW);
  const sel = await G.ui.choice([
    { label: "ミケを信じて、眠る" },
    { label: "ナースコールを押す" },
  ], "……どうする?");
  if (sel === 0) {
    await G.fx.fadeOut("#000000", 1200);
    await runEnding(G, "bad4");
    return false;
  }
  // ナースコール
  G.audio.sfx("call");
  G.fx.flash("#ffffff", 500);
  await sleep(600);
  G.audio.sfx("steps_run");
  await sleep(900);
  G.stage.dark = 0.12;
  G.stage.setChars([{ id: "kaede_gauze", x: 150 }]);
  G.fx.flash("#ffffff", 400);
  await G.ui.lines([
    [N.kaede, "……うん。よく、押せたね。"],
    [N.mio, "…………。"],
    [N.kaede, "今夜は、もう大丈夫。ゆっくり、おやすみ。"],
  ]);
  await G.fx.fadeOut("#000000", 1100);
  return true;
}

// ---------------- 第5章 合言葉 ----------------
async function pCh5(G: Game): Promise<boolean> {
  cp(G, "ch5");
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_room", false);
  G.stage.setChars([{ id: "kaede_gauze", x: 168 }]);
  G.audio.bgm("realWarm", 1200);
  await G.fx.fadeIn(900);
  await G.ui.lines(CH5_MORNING);
  G.audio.sfx("get");
  await G.ui.lines(CH5_GET);
  G.stage.setChars([]);
  await G.fx.fadeOut("#000000", 700);

  let calls = 0;
  const objectives = [
    "院内を歩いて過ごす(空が熟れたら C でナースコール)",
    "あいことばは、あと2回(C でナースコール)",
    "あいことばは、あと1回(C でナースコール)",
  ];
  await G.scenes.run(
    new ExploreScene(G, {
      side: "real",
      startMap: "hall",
      spawn: [4, 6],
      objective: objectives[0],
      markers: [],
      ripeness: 56,
      ripeRate: 1.1,
      allowCall: true,
      time: "day",
      onCall: async (api: ExploreAPI) => {
        api.ripeness = 24;
        G.audio.sfx("steps_run");
        calls++;
        G.fx.flash("#ffffff", 400);
        await G.ui.say(N.mio, "……空が、熟れてきました。");
        if (calls === 1) {
          await G.ui.lines(CH5_CLUE1);
          api.setObjective(objectives[1]);
          return false;
        }
        if (calls === 2) {
          await G.ui.lines(CH5_CLUE2);
          api.setObjective(objectives[2]);
          return false;
        }
        await G.ui.lines(CH5_CLUE3);
        return true;
      },
      onRipeFull: async (api: ExploreAPI) => {
        G.fx.flash("#ff3d6e", 700);
        G.audio.sfx("whiteout");
        await G.ui.lines([
          [null, "空が、熟れ落ちかけた。——だが、誰かの足音が、すぐ近くにあった。"],
          [null, "白い門番は、もう、怪物じゃない。ひとりひとり、違う顔があった。"],
        ]);
        api.ripeness = 40;
      },
    })
  );
  G.stage.show = true;
  G.stage.setBg("real_room", false);
  G.audio.bgm("realWarm", 800);
  await G.fx.fadeIn(800);
  await G.ui.lines([[null, "合言葉を使うたびに、手がかりが、ひとつずつ増えていく。"]]);
  await G.fx.fadeOut("#000000", 700);
  return true;
}

// ---------------- 第6章 七通の封筒 ----------------
async function pCh6(G: Game): Promise<boolean> {
  cp(G, "ch6");
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_lounge", false);
  G.stage.setProps(["letters"]);
  G.audio.bgm("realWarm", 900);
  await G.fx.fadeIn(900);
  await G.ui.lines([
    [null, "談話室の棚に、封筒が七通。輪ゴムでまとめて、置いてある。"],
    [null, "差出人は、全部、同じ。——母。"],
  ]);
  for (let i = 0; i < 7; i++) {
    const sel = await G.ui.choice(
      i === 0
        ? [{ label: "読むのをやめる" }, { label: "一通目を、開く" }]
        : [{ label: "読むのをやめる" }, { label: i === 6 ? "七通目を、開く" : "次の一通を、開く" }],
      "封筒"
    );
    if (sel === 0) {
      await runEnding(G, "bad5");
      return false;
    }
    await G.scenes.run(new LetterScene(G, i, LETTERS[i]));
  }
  G.stage.setProps([]);
  await G.ui.lines(CH6_AFTER.slice(0, 3));
  G.stage.setChars([{ id: "mike", x: 252 }]);
  G.audio.sfx("nyaa");
  await G.ui.lines(CH6_AFTER.slice(3, 5));
  G.stage.setChars([]);
  await G.ui.lines([CH6_AFTER[5]]);
  G.stage.setChars([{ id: "mike", x: 252 }]);
  await G.ui.lines(CH6_AFTER.slice(6));
  G.stage.setChars([]);
  await G.fx.fadeOut("#000000", 900);
  return true;
}

// ---------------- 第7章 面会の通知 ----------------
async function pCh7(G: Game): Promise<boolean> {
  cp(G, "ch7");
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_room", false);
  G.stage.setChars([{ id: "kaede_gauze", x: 168 }]);
  G.audio.bgm("realWarm", 900);
  await G.fx.fadeIn(900);
  await G.ui.lines(CH7_NOTICE);
  const sel = await G.ui.choice([
    { label: "「会いたくない」と、断る" },
    { label: "「会います」と、受ける" },
  ], "面会の通知");
  if (sel === 0) {
    await G.ui.lines([[N.kaede, "……わかりました。無理は、しなくていいからね。"]]);
    await runEnding(G, "bad6");
    return false;
  }
  await G.ui.lines(CH7_ACCEPT);
  G.stage.setChars([]);
  await G.fx.fadeOut("#000000", 800);

  // 面会までの一週間
  const markerPlan: { map: string; x: number; y: number }[] = [
    { map: "lounge", x: 5, y: 5 },
    { map: "courtyard", x: 11, y: 8 },
    { map: "hall", x: 30, y: 7 },
    { map: "station", x: 10, y: 6 },
    { map: "courtyard", x: 11, y: 8 },
    { map: "room", x: 5, y: 3 },
  ];
  let day = 0;
  let finished = false;
  await G.scenes.run(
    new ExploreScene(G, {
      side: "real",
      startMap: "room",
      spawn: [9, 11],
      objective: CH7_DAYS[0],
      markers: [{ id: "m0", map: markerPlan[0].map, x: markerPlan[0].x, y: markerPlan[0].y }],
      ripeness: 46,
      ripeRate: 0.5,
      allowCall: true,
      time: "day",
      hanaLines: HANA_WEEK[0],
      onMarker: async (_id: string, api: ExploreAPI) => {
        await G.fx.fadeOut("#000000", 500);
        await G.fx.fadeIn(500);
        if (day < HANA_WEEK.length && (day === 0 || day === 1 || day === 3 || day === 4)) {
          await G.ui.lines(HANA_WEEK[Math.min(day, HANA_WEEK.length - 1)]);
        }
        if (day % 2 === 1) {
          G.fx.flash("#8a1250", 500);
          await G.ui.lines(CH7_MIKE[(day >> 1) % CH7_MIKE.length]);
        }
        day++;
        api.ripeness = Math.min(96, api.ripeness + 15);
        if (day >= 6) {
          finished = true;
          await G.ui.lines([[null, "——日曜日の、朝。"]]);
          return true;
        }
        api.setObjective(CH7_DAYS[day]);
        api.setMarkers([{ id: `m${day}`, map: markerPlan[day].map, x: markerPlan[day].x, y: markerPlan[day].y }]);
        G.ui.toast(CH7_DAYS[day], 3000);
        return false;
      },
      onCall: async (api: ExploreAPI) => {
        api.ripeness = 26;
        G.audio.sfx("steps_run");
        G.fx.flash("#ffffff", 400);
        await G.ui.lines(CH7_CALL_KAEDE);
        return false;
      },
      onRipeFull: async (api: ExploreAPI) => {
        G.fx.flash("#ff3d6e", 800);
        await G.ui.lines([
          [null, "空が、熟れ落ちかけた。——肩に、そっと手が置かれた。"],
          [N.kaede, "「空が、熟れてきました」……ね。私からも、言っておくね。"],
        ]);
        api.ripeness = 38;
      },
    })
  );
  void finished;
  await G.fx.fadeOut("#000000", 500);
  return true;
}

// ---------------- 第8章 面会室(最終戦) ----------------
async function pCh8(G: Game): Promise<boolean> {
  cp(G, "ch8");
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_visiting", false);
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }]);
  G.audio.bgm("realWarm", 900);
  await G.fx.fadeIn(1000);
  await G.ui.lines(CH8_VISIT.slice(0, 2));
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }, { id: "mother", x: 224 }]);
  await G.ui.lines(CH8_VISIT.slice(2, 5));
  G.stage.setProps(["collar"]);
  G.audio.sfx("whisper");
  await G.ui.lines(CH8_VISIT.slice(5));
  // 空が裂ける
  G.audio.sfx("crack");
  await G.fx.bleed(() => {
    G.stage.setBg("battle4_0", true);
    G.stage.setChars([]);
    G.stage.setProps([]);
    G.audio.bgm("final", 300);
  }, 1500);
  G.stage.setChars([{ id: "mike", x: 250 }]);
  await G.ui.lines(CH8_WITCH_INTRO);
  G.stage.setChars([]);

  const res = (await G.scenes.run(
    new BattleScene(G, {
      id: "witch",
      enemyName: BATTLE_NAMES.witch,
      canSpare: false,
      spareNote: SPARE_NOTE_GATE,
      whispers: MIKE_WHISPERS.witch,
      intro: [
        "——頭が七色に煮えたぎる鍋の、巨大な影。「猫殺しの魔女」。",
        "ミケ「今にゃ、澪。今しかないにゃ」",
      ],
    })
  )).result;

  if (res === "crit") {
    // バッド7:ミケだにゃ
    await runEnding(G, "bad7");
    return false;
  }

  // ---------------- 第9章 ミケの声 ----------------
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_visiting", false);
  G.stage.setProps(["collar"]);
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }, { id: "mother", x: 224 }]);
  G.audio.bgm("realWarm", 1200);
  await G.fx.fadeOut("#ffffff", 0);
  await G.fx.fadeIn(1600);
  await G.ui.lines(CH9_ROOM.slice(0, 4));
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }, { id: "mother", x: 224 }, { id: "mike", x: 266, alpha: 0.7 }]);
  await G.ui.lines(CH9_ROOM.slice(4, 8));
  // ミケが溶ける
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }, { id: "mother", x: 224 }, { id: "mike", x: 266, alpha: 0.4 }]);
  await sleep(500);
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }, { id: "mother", x: 224 }, { id: "mike", x: 266, alpha: 0.18 }]);
  G.fx.flash("#ffffff", 1200);
  await sleep(900);
  G.stage.setChars([{ id: "kaede_gauze", x: 96 }, { id: "mother", x: 224 }]);
  await G.ui.lines(CH9_ROOM.slice(8));

  // トゥルーエンド
  G.save.d.cleared = true;
  G.save.d.unlockedCall = true;
  G.save.d.checkpoint = "prologue";
  G.save.commit();
  await runEnding(G, "true");
  return true;
}

// ---------------- ナースコールを、押す(解放後の項目) ----------------
export async function nurseCallMini(G: Game): Promise<void> {
  G.stage.reset();
  G.stage.show = true;
  G.stage.setBg("real_station", false);
  G.stage.dark = 0.5;
  G.audio.bgm("real", 600);
  await G.fx.fadeIn(800);
  await G.ui.lines([
    [null, "——夜の、病棟。ナースステーションの灯だけが、点いている。"],
    [null, "ボタンの前に立つ。いつかの自分に、代わるように。"],
  ]);
  const sel = await G.ui.choice([{ label: "ナースコールを、押す" }], "");
  void sel;
  G.audio.sfx("call");
  G.fx.flash("#ffffff", 800);
  await sleep(700);
  G.audio.sfx("steps_run");
  await sleep(1000);
  G.stage.dark = 0.1;
  G.stage.setChars([{ id: "kaede", x: 168 }]);
  G.fx.flash("#ffffff", 500);
  await G.ui.lines([
    [N.kaede, "——はい。どうしましたか。"],
    [null, "……空が、熟れてきました。"],
    [null, "ちゃんと、言えてる。ひとりで、戦わなくていい。"],
    [N.kaede, "うん。いつでも、押していいんだよ。"],
  ]);
  await G.fx.fadeOut("#000000", 900);
}

// ---------------- 物語ディスパッチャ ----------------
export async function story(G: Game, from: string): Promise<void> {
  const seq: [string, (g: Game) => Promise<boolean>][] = [
    ["prologue", pPrologue],
    ["ch1", pCh1],
    ["ch2", pCh2],
    ["ch3", pCh3],
    ["ch4", pCh4],
    ["ch5", pCh5],
    ["ch6", pCh6],
    ["ch7", pCh7],
    ["ch8", pCh8],
  ];
  let i = seq.findIndex((s) => s[0] === from);
  if (i < 0) i = 0;
  for (; i < seq.length; i++) {
    const ok = await seq[i][1](G);
    if (!ok) return; // バッドエンド → タイトルへ
  }
}
