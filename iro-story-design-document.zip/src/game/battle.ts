// ============================================================
// いろ — 戦闘シーン(弾幕回避 + アタックバー + 各戦闘固有ルール)
// ============================================================
import type { BattleConfig, BattleResult, Ctx2D, Game, Scene } from "./types";
import {
  drawAttackBar, drawBG, drawGatekeeper, drawGyorome, drawHeart, drawHoneyQueen,
  drawHourglass, drawMike, drawWitch, FONT, rainbowText, text,
} from "./art";

type Mode = "intro" | "menu" | "bar" | "resolve" | "enemy" | "dead" | "event" | "out";

interface Bullet {
  x: number; y: number; vx: number; vy: number; r: number;
  kind: "orb" | "drop" | "nya" | "hand";
  wob: number; dmg: number; dead?: boolean; spin?: number;
}

const BOX = { x: 86, y: 128, w: 148, h: 86 };

export class BattleScene implements Scene {
  done = false;
  result: BattleResult = null;

  private mode: Mode = "intro";
  private t = 0;
  private modeT = 0;
  private turn = 0;

  private hp = 20;
  private readonly maxhp = 20;
  private heart = { x: BOX.x + BOX.w / 2, y: BOX.y + BOX.h / 2, iframe: 0 };
  private bullets: Bullet[] = [];
  private spawnT = 0;
  private hitsThisTurn = 0;

  // メニュー
  private menuIndex = 0; // 0=たたかう 1=みのがす
  // アタックバー
  private bars: { pos: number; dir: number; stopped: boolean; locked: boolean }[] = [];
  private lockedX: number | null = null;
  private zone: "crit" | "hit" | "miss" = "miss";
  private critHalf = 0.055;
  private autoT = 0;
  private feedback: { text: string; until: number; color: string } | null = null;

  // 固有
  private spareCount = 0;
  private spareArmed = false;
  private survive = 0;
  private peels = 0;
  private hourglass = 60;
  private gatePhase: "none" | "enter" | "wide" = "none"; // 最終戦の白い門番
  private enemyAlpha = 1;
  private enemyAng = 0;
  private introIdx = 0;
  private endingT = 0;

  private deathLine = "ほらね。だから、言ったのにゃ。";

  constructor(private G: Game, private cfg: BattleConfig) {}

  enter() {
    this.G.stage.show = false;
    this.G.ui.objective(null);
    this.G.ui.setGauge(null);
    this.G.audio.bgm(this.cfg.id === "witch" ? "final" : "battle", 500);
    this.mode = "intro";
    this.modeT = 0;
  }
  exit() {
    this.G.audio.bgm(null, 400);
  }

  // ---------------- ユーティリティ ----------------
  private whisper(): string {
    const list = this.cfg.whispers;
    return list[this.turn % list.length];
  }
  private fb(s: string, color = "#f2f2f6", ms = 1300) {
    this.feedback = { text: s, until: performance.now() + ms, color };
  }
  private resetBattle() {
    this.hp = this.maxhp;
    this.bullets = [];
    this.turn = 0;
    this.spareCount = 0;
    this.spareArmed = false;
    this.survive = 0;
    this.peels = 0;
    this.hourglass = 60;
    this.critHalf = 0.055;
    this.enemyAlpha = 1;
    this.enemyAng = 0;
    this.menuIndex = 0;
    this.heart = { x: BOX.x + BOX.w / 2, y: BOX.y + BOX.h / 2, iframe: 0 };
    this.mode = "menu";
    this.modeT = 0;
  }

  private startBars() {
    this.bars = [];
    if (this.cfg.id === "gatekeepers") {
      for (let i = 0; i < 3; i++) {
        this.bars.push({
          pos: Math.random(),
          dir: Math.random() > 0.5 ? 1 : -1,
          stopped: i === 2,
          locked: false,
        });
      }
    } else {
      this.bars.push({ pos: Math.random(), dir: Math.random() > 0.5 ? 1 : -1, stopped: false, locked: false });
    }
    this.lockedX = null;
    this.autoT = 0;
    this.mode = "bar";
    this.modeT = 0;
  }

  private activeBarIndex(): number {
    if (this.cfg.id === "gatekeepers") return Math.min(this.turn, 2);
    return 0;
  }

  private lockBar(x: number) {
    this.lockedX = x;
    const dist = Math.abs(x - 0.5);
    if (dist <= this.critHalf) this.zone = "crit";
    else if (dist <= 0.27) this.zone = "hit";
    else this.zone = "miss";
    this.G.audio.sfx("swing");
    this.mode = "resolve";

    const id = this.cfg.id;
    // 終端の分岐
    if (id === "gyorome") { this.G.audio.sfx("slash"); this.beginOutro("fought"); return; }
    if (id === "honey") { this.G.audio.sfx("slash"); this.beginOutro("fought"); return; }
    if (id === "witch" && this.zone === "crit") { this.G.audio.sfx("slash"); this.beginOutro("crit"); return; }
    if (id === "gatekeepers" && this.activeBarIndex() === 2) { this.G.audio.sfx("slash"); this.beginOutro("cut3"); return; }
    // 通常解決
    if (id === "gatekeepers") {
      if (this.zone === "miss") {
        this.fb("……はずれ。門番の手は、まだ伸びてくる。", "#c9c9d0");
        this.G.audio.sfx("cancel");
        // 同じバーでやり直し
        setTimeout(() => { if (!this.done && this.mode === "resolve") this.startBars(); }, 700);
      } else {
        this.G.audio.sfx("slash");
        this.G.fx.shake(4, 260);
        this.fb(this.zone === "crit" ? "腕を、深く払った!" : "腕を、払った。", "#ffe9c9");
        setTimeout(() => { if (!this.done && this.mode === "resolve") { this.turn++; this.startEnemyTurn(); } }, 650);
      }
      return;
    }
    if (id === "witch") {
      if (this.zone === "hit") {
        this.peels = Math.min(5, this.peels + 1);
        this.G.audio.sfx("shatter");
        this.G.fx.shake(3, 200);
        this.fb("色が、一枚、剥がれていく……。", "#dcdce6");
        if (this.peels >= 5) this.hourglass = Math.min(this.hourglass, 2.2);
      } else {
        this.fb("……はずれ、にゃ。", "#c05aff");
        this.G.audio.sfx("cancel");
      }
      setTimeout(() => {
        if (!this.done && this.mode === "resolve") {
          this.turn++;
          this.critHalf = Math.min(0.24, 0.055 + this.turn * 0.035);
          this.startEnemyTurn();
        }
      }, 700);
      return;
    }
  }

  private beginOutro(r: BattleResult) {
    this.mode = "out";
    this.modeT = 0;
    this.endingT = 0;
    this.result = r;
    if (r === "crit" || r === "fought") this.G.fx.shake(6, 500);
  }

  private startEnemyTurn() {
    if (this.done) return;
    this.mode = "enemy";
    this.modeT = 0;
    this.hitsThisTurn = 0;
    this.spawnT = 0;
    this.bullets = [];
    this.heart.x = BOX.x + BOX.w / 2;
    this.heart.y = BOX.y + BOX.h / 2;
  }

  private enemyDur(): number {
    switch (this.cfg.id) {
      case "gyorome": return this.spareCount >= 1 ? 2.6 : 3.8;
      case "honey": return 4.6;
      case "gatekeepers": return 3.2;
      case "witch": return 5.6;
    }
  }

  private endEnemyTurn() {
    const id = this.cfg.id;
    if (id === "honey" && this.spareArmed) {
      if (this.hitsThisTurn === 0) {
        this.survive++;
        if (this.survive >= 3) {
          // 最後のしずくが口に落ちる
          this.mode = "event";
          this.modeT = 0;
          this.G.audio.sfx("drop");
          return;
        }
        this.fb(`耐えた。……あと${3 - this.survive}呼吸。`, "#ffe9c9");
      } else {
        this.survive = 0;
        this.fb("蜜が、尻尾を巻く。……もう一度。", "#ffb0b0");
      }
    }
    if (id === "gyorome" && this.spareCount === 1) {
      this.fb("影は、まだ、こちらを見ている……。", "#c9c9d0");
    }
    if (id === "gatekeepers") {
      // 次のバーへ(3本目は終端)
      if (this.turn >= 2) { this.startBars(); return; }
    }
    this.mode = "menu";
    this.modeT = 0;
  }

  // ---------------- 弾幕 ----------------
  private spawnBullet(dt: number) {
    const id = this.cfg.id;
    this.spawnT -= dt;
    if (this.spawnT > 0) return;
    const bx = BOX.x, by = BOX.y, bw = BOX.w, bh = BOX.h;
    const R = Math.random;
    if (id === "gyorome") {
      this.spawnT = 0.55;
      const side = Math.floor(R() * 4);
      let x = bx, y = by;
      let vx = 0, vy = 0;
      const cx = bx + bw / 2, cy = by + bh / 2;
      if (side === 0) { x = bx - 6; y = by + R() * bh; vx = 1; }
      if (side === 1) { x = bx + bw + 6; y = by + R() * bh; vx = -1; }
      if (side === 2) { x = bx + R() * bw; y = by - 6; vy = 1; }
      if (side === 3) { x = bx + R() * bw; y = by + bh + 6; vy = -1; }
      const ang = Math.atan2(cy - y, cx - x);
      const sp = 26 + R() * 14;
      this.bullets.push({
        x, y, vx: Math.cos(ang) * sp + vx * 6, vy: Math.sin(ang) * sp + vy * 6,
        r: 3.4, kind: "orb", wob: R() * 6.28, dmg: 2,
      });
    } else if (id === "honey") {
      this.spawnT = 0.42;
      if (R() < 0.72) {
        this.bullets.push({
          x: bx + 6 + R() * (bw - 12), y: by - 8, vx: (R() - 0.5) * 8, vy: 24 + R() * 12,
          r: 3.2, kind: "drop", wob: R() * 6.28, dmg: 3,
        });
      } else {
        this.bullets.push({
          x: bx - 8, y: by + 10 + R() * (bh - 20), vx: 34 + R() * 10, vy: 0,
          r: 3.4, kind: "orb", wob: R() * 6.28, dmg: 3, spin: 1,
        });
      }
    } else if (id === "gatekeepers") {
      this.spawnT = 0.6;
      const fromLeft = R() < 0.5;
      this.bullets.push({
        x: fromLeft ? bx - 10 : bx + bw + 10, y: by + 8 + R() * (bh - 16),
        vx: fromLeft ? 30 : -30, vy: 0, r: 4.4, kind: "hand", wob: R() * 6.28, dmg: 3,
      });
      if (R() < 0.4) {
        this.bullets.push({
          x: bx + R() * bw, y: by - 8, vx: 0, vy: 20 + R() * 10,
          r: 3, kind: "orb", wob: 0, dmg: 2,
        });
      }
    } else if (id === "witch") {
      this.spawnT = 0.34;
      const drift = R() < 0.5;
      this.bullets.push({
        x: bx + R() * bw, y: by - 10,
        vx: drift ? 14 + R() * 10 : -(14 + R() * 10), vy: 30 + R() * 14,
        r: 4.6, kind: "nya", wob: R() * 6.28, dmg: 3,
      });
    }
  }

  private updateBullets(dt: number) {
    for (const b of this.bullets) {
      b.wob += dt * (b.kind === "nya" ? 3 : 5);
      if (b.kind === "nya" || b.kind === "orb") {
        b.x += (b.vx + Math.sin(b.wob) * (b.kind === "nya" ? 16 : 10)) * dt;
        b.y += b.vy * dt;
      } else if (b.kind === "drop") {
        b.vy += 20 * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
      } else {
        b.x += b.vx * dt;
        b.y += Math.sin(b.wob) * 8 * dt;
      }
      if (b.x < BOX.x - 30 || b.x > BOX.x + BOX.w + 30 || b.y < BOX.y - 30 || b.y > BOX.y + BOX.h + 30) b.dead = true;
      // 被弾
      const h = this.heart;
      const dx = b.x - h.x, dy = b.y - h.y;
      if (!b.dead && h.iframe <= 0 && dx * dx + dy * dy < (b.r + 3.6) * (b.r + 3.6)) {
        b.dead = true;
        h.iframe = 0.75;
        this.hp = Math.max(0, this.hp - b.dmg);
        this.hitsThisTurn++;
        this.G.audio.sfx("hurt");
        this.G.fx.shake(3.4, 240);
        this.G.fx.flash("#601018", 160);
      }
    }
    this.bullets = this.bullets.filter((b) => !b.dead);
  }

  // ---------------- 更新 ----------------
  update(dt: number) {
    this.t += dt;
    this.modeT += dt;
    const G = this.G;
    const id = this.cfg.id;

    if (this.heart.iframe > 0) this.heart.iframe -= dt;

    // 砂時計(最終戦)
    if (id === "witch" && (this.mode === "menu" || this.mode === "bar" || this.mode === "enemy" || this.mode === "resolve")) {
      const before = this.hourglass;
      this.hourglass -= dt;
      if (Math.ceil(this.hourglass) !== Math.ceil(before) && this.hourglass < 10) G.audio.sfx("hourglass");
      if (this.hourglass <= 0) {
        // 白い門番が現れる
        this.mode = "event";
        this.modeT = 0;
        this.gatePhase = "enter";
        this.bullets = [];
        G.audio.sfx("whiteout");
        return;
      }
    }

    switch (this.mode) {
      case "intro": {
        if (G.input.consume("z")) {
          this.introIdx++;
          G.audio.sfx("text");
        }
        const intro = this.cfg.intro ?? [];
        if (this.introIdx >= intro.length) {
          this.mode = "menu";
          this.modeT = 0;
        }
        break;
      }
      case "menu": {
        const canSpare = this.cfg.canSpare;
        if (G.input.consume("left") || G.input.consume("up")) { this.menuIndex = 0; G.audio.sfx("cursor"); }
        if (G.input.consume("right") || G.input.consume("down")) { this.menuIndex = 1; G.audio.sfx("cursor"); }
        if (G.input.consume("z")) {
          if (this.menuIndex === 0) {
            G.audio.sfx("confirm");
            this.startBars();
          } else if (!canSpare) {
            G.audio.sfx("disabled");
            this.fb(this.cfg.spareNote ?? "……選べない。", "#8a8a92");
          } else {
            G.audio.sfx("confirm");
            if (id === "gyorome") {
              this.spareCount++;
              if (this.spareCount >= 2) {
                this.mode = "event";
                this.modeT = 0;
                this.fb("");
                return;
              }
              this.fb("剣を、下ろした。影は、少しだけ戸惑った。", "#dcdce6");
              this.startEnemyTurn();
            } else if (id === "honey") {
              this.spareArmed = true;
              this.fb("剣を、下ろして、耐える。……蜜の匂いが、満ちる。", "#dcdce6");
              this.startEnemyTurn();
            }
          }
        }
        break;
      }
      case "bar": {
        const idx = this.activeBarIndex();
        const bar = this.bars[idx];
        if (!bar.stopped) {
          bar.pos += bar.dir * dt * 0.85;
          if (bar.pos > 1) { bar.pos = 1; bar.dir = -1; }
          if (bar.pos < 0) { bar.pos = 0; bar.dir = 1; }
        }
        // 最終戦:放置でミケが振るう
        if (id === "witch") {
          this.autoT += dt;
          const lim = Math.max(1.6, 4 - this.turn * 0.25);
          if (this.autoT > lim) {
            this.lockBar(0.5); // ミケが勝手に剣を振る(中央判定)
            break;
          }
        }
        if (G.input.consume("z")) this.lockBar(bar.pos);
        break;
      }
      case "resolve": {
        // lockBar内で遷移処理済み。時間経過でフェード
        break;
      }
      case "enemy": {
        this.spawnBullet(dt);
        this.updateBullets(dt);
        // 心臓の移動
        const sp = 96 * dt;
        if (G.input.held("up")) this.heart.y -= sp;
        if (G.input.held("down")) this.heart.y += sp;
        if (G.input.held("left")) this.heart.x -= sp;
        if (G.input.held("right")) this.heart.x += sp;
        this.heart.x = Math.max(BOX.x + 6, Math.min(BOX.x + BOX.w - 6, this.heart.x));
        this.heart.y = Math.max(BOX.y + 6, Math.min(BOX.y + BOX.h - 6, this.heart.y));
        if (this.hp <= 0) {
          this.mode = "dead";
          this.modeT = 0;
          G.audio.sfx("heart_break");
          this.bullets = [];
          break;
        }
        if (this.modeT >= this.enemyDur()) this.endEnemyTurn();
        break;
      }
      case "dead": {
        if (this.modeT > 0.8 && G.input.consume("z")) {
          this.resetBattle();
          this.fb("……同じ朝が、また来る。同じ夜が。", "#c05aff");
        }
        break;
      }
      case "event": {
        // イベント(ハニー救済の雫 / ギョロメ消失 / 最終戦の門番)
        if (id === "honey") {
          if (this.modeT > 2.2) this.beginOutro("spared");
        } else if (id === "gyorome") {
          this.enemyAlpha = Math.max(0, this.enemyAlpha - dt * 0.8);
          if (this.modeT > 2.0) this.beginOutro("spared");
        } else if (id === "witch") {
          if (this.modeT > 1.4 && this.gatePhase === "enter") {
            this.gatePhase = "wide";
          }
          if (this.modeT > 2.2) {
            // 画面を白へ
            G.fx.flash("#ffffff", 1400);
            if (this.modeT > 3.4) this.beginOutro("cleansed");
          }
        }
        break;
      }
      case "out": {
        this.endingT += dt;
        if (this.result === "fought") {
          this.enemyAlpha = Math.max(0, this.enemyAlpha - dt * 0.7);
          this.enemyAng += dt * 2;
        }
        if (this.result === "crit") {
          // 魔女の崩壊→暗転
          if (this.endingT > 0.5 && this.endingT < 0.6) G.fx.flash("#ffffff", 300);
          if (this.endingT > 0.9) {
            this.enemyAlpha = Math.max(0, this.enemyAlpha - dt * 1.4);
          }
          if (this.endingT > 1.8) {
            void G.fx.fadeOut("#000000", 700);
          }
          if (this.endingT > 2.6) this.done = true;
        } else if (this.endingT > 2.0) {
          this.done = true;
        }
        break;
      }
    }
  }

  // ---------------- 描画 ----------------
  draw(g: Ctx2D) {
    const id = this.cfg.id;
    // 背景
    if (id === "witch") {
      drawBG(g, `battle4_${Math.min(4, this.peels)}`, this.t);
    } else {
      drawBG(g, "battle_123", this.t);
    }

    // 敵
    if (id === "gyorome") {
      drawGyorome(g, 160, 78, this.t, this.enemyAlpha);
    } else if (id === "honey") {
      g.save();
      g.translate(160, 76);
      g.rotate(this.result === "fought" ? Math.min(1.2, this.enemyAng) : Math.sin(this.t * 1.1) * 0.04);
      drawHoneyQueen(g, 0, 0, this.t, this.enemyAlpha);
      g.restore();
    } else if (id === "gatekeepers") {
      // 二体の大 + 中央に小(3体目)
      const swayL = this.turn === 0 && (this.mode === "enemy" || this.mode === "resolve") ? 8 : 0;
      const swayR = this.turn === 1 && (this.mode === "enemy" || this.mode === "resolve") ? 8 : 0;
      drawGatekeeper(g, 84 - swayL, 118, this.t, false, 0.94);
      drawGatekeeper(g, 236 + swayR, 118, this.t, false, 0.94);
      const smallArms = this.turn >= 2;
      drawGatekeeper(g, 160, 106, this.t, true, 1, smallArms);
      if (this.result === "cut3") {
        // 斬撃の残光
        g.save();
        g.globalAlpha = this.enemyAlpha;
        g.strokeStyle = "#ffffff";
        g.lineWidth = 3;
        g.shadowColor = "#fff"; g.shadowBlur = 12;
        g.beginPath();
        g.moveTo(80, 40); g.lineTo(240, 120);
        g.stroke();
        g.restore();
      }
    } else if (id === "witch") {
      drawWitch(g, 160, 96, this.t, Math.min(5, this.peels));
      if (this.mode === "event" && this.gatePhase !== "none") {
        // 白い門番が魔女の前に
        const k = this.gatePhase === "wide" ? 1 : Math.min(1, this.modeT / 1.2);
        drawGatekeeper(g, 160, 190 - (1 - k) * 60, this.t, true, k, this.gatePhase === "wide");
      }
    }

    // 弾幕ボックス
    g.save();
    g.fillStyle = "rgba(3,3,8,0.82)";
    g.fillRect(BOX.x, BOX.y, BOX.w, BOX.h);
    g.strokeStyle = "#f2f2f6";
    g.lineWidth = 2;
    g.strokeRect(BOX.x + 1, BOX.y + 1, BOX.w - 2, BOX.h - 2);
    g.beginPath();
    g.rect(BOX.x + 2, BOX.y + 2, BOX.w - 4, BOX.h - 4);
    g.clip();
    // 弾
    for (const b of this.bullets) {
      if (b.kind === "nya") {
        g.save();
        g.font = `10px ${FONT}`;
        g.fillStyle = ["#52ff6a", "#c05aff", "#31b8ff"][Math.floor(b.wob) % 3];
        g.textAlign = "center";
        g.fillText("にゃ", b.x, b.y + 4);
        g.restore();
      } else if (b.kind === "drop") {
        g.fillStyle = "#ffc41e";
        g.beginPath();
        g.ellipse(b.x, b.y, b.r * 0.8, b.r * 1.25, 0, 0, Math.PI * 2);
        g.fill();
      } else if (b.kind === "hand") {
        g.fillStyle = "#f4f4f8";
        g.beginPath();
        g.ellipse(b.x, b.y, b.r * 1.4, b.r, 0, 0, Math.PI * 2);
        g.fill();
        g.strokeStyle = "rgba(120,120,140,0.6)";
        g.lineWidth = 1;
        g.stroke();
      } else {
        const hues = ["#ffe14d", "#ff6a9e", "#52ff6a"];
        g.fillStyle = hues[Math.floor(b.wob * 2) % 3];
        g.beginPath();
        g.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        g.fill();
        g.strokeStyle = "rgba(255,255,255,0.7)";
        g.lineWidth = 1;
        g.stroke();
      }
    }
    // 心臓
    if (this.mode === "enemy" || this.mode === "dead") {
      const blink = this.heart.iframe > 0 && Math.floor(this.t * 12) % 2 === 0;
      if (!blink) {
        drawHeart(g, this.heart.x - 5, this.heart.y - 4, 10, "#ff2e4d");
        g.strokeStyle = "#ffffff";
        g.lineWidth = 1;
        g.strokeRect(this.heart.x - 5.5, this.heart.y - 4.5, 10, 9);
      }
    }
    g.restore();

    // HPハート(左上)
    for (let i = 0; i < this.maxhp; i++) {
      const hx = 10 + (i % 10) * 11;
      const hy = 10 + Math.floor(i / 10) * 10;
      drawHeart(g, hx, hy, 6, i < this.hp ? "#ff2e4d" : "#3a3a42");
    }

    // 砂時計(最終戦)
    if (id === "witch" && this.mode !== "intro") {
      const frac = Math.max(0, this.hourglass / 60);
      drawHourglass(g, 294, 12, frac, this.t);
      if (this.hourglass < 10) {
        text(g, `${Math.ceil(Math.max(0, this.hourglass))}`, 296, 40, { size: 9, color: "#ff6a6a" });
      }
    }

    // メニュー
    if (this.mode === "menu") {
      this.drawCommand(g, 8, 224 - 4, 120, "たたかう", this.menuIndex === 0, true);
      this.drawCommand(g, 134, 224 - 4, 120, "みのがす", this.menuIndex === 1, this.cfg.canSpare);
    }

    // アタックバー
    if (this.mode === "bar" || this.mode === "resolve") {
      const idx = this.activeBarIndex();
      if (id === "gatekeepers") {
        this.bars.forEach((b, i) => {
          drawAttackBar(g, 30, 148 + i * 20, 260, 12, b.locked || this.lockedX === null ? (i === idx ? (this.lockedX ?? b.pos) : (b.stopped ? 0.5 : b.pos)) : this.lockedX, this.critHalf, i === idx, this.t);
        });
      } else {
        drawAttackBar(g, 30, 222, 260, 12, this.lockedX ?? this.bars[0]?.pos ?? 0, this.critHalf, true, this.t);
      }
    }

    // イベント演出
    if (this.mode === "event") {
      if (id === "honey") {
        // 最後のしずく
        const k = Math.min(1, this.modeT / 2);
        const dy = 90 + k * 90;
        g.fillStyle = "#ffc41e";
        g.beginPath();
        g.ellipse(160, dy, 3.2, 4.4, 0, 0, Math.PI * 2);
        g.fill();
        g.fillStyle = "rgba(255,255,255,0.65)";
        g.beginPath();
        g.ellipse(159, dy - 1, 1, 1.6, 0, 0, Math.PI * 2);
        g.fill();
      }
      if (id === "gyorome") {
        // 闇に溶ける
        g.save();
        g.globalAlpha = 1 - this.enemyAlpha;
        g.fillStyle = "#05050a";
        g.fillRect(0, 0, 320, 240);
        g.restore();
      }
      if (id === "witch" && this.gatePhase === "wide") {
        const k = Math.min(1, (this.modeT - 2.2) / 1.2);
        g.save();
        g.globalAlpha = Math.max(0, k) * 0.9;
        g.fillStyle = "#ffffff";
        g.fillRect(0, 0, 320, 240);
        g.restore();
      }
    }

    // DEAD暗転
    if (this.mode === "dead") {
      const k = Math.min(1, this.modeT / 1.2);
      g.save();
      g.globalAlpha = 0.75 * k;
      g.fillStyle = "#05050a";
      g.fillRect(0, 0, 320, 240);
      g.restore();
    }

    // 魔女クリティカルの暗転
    if (this.mode === "out" && this.result === "crit") {
      const k = Math.min(1, Math.max(0, (this.endingT - 1.6) / 1));
      g.save();
      g.globalAlpha = k;
      g.fillStyle = "#000";
      g.fillRect(0, 0, 320, 240);
      g.restore();
    }
  }

  private drawCommand(g: Ctx2D, x: number, y: number, w: number, label: string, sel: boolean, enabled: boolean) {
    g.save();
    g.fillStyle = sel ? "rgba(240,240,250,0.18)" : "rgba(6,6,12,0.7)";
    g.fillRect(x, y, w, 15);
    g.strokeStyle = enabled ? (sel ? "#f2f2f6" : "#7a7a84") : "#4a4a52";
    g.lineWidth = 1.5;
    g.strokeRect(x + 0.5, y + 0.5, w - 1, 14);
    g.font = `10px ${FONT}`;
    g.textAlign = "center";
    g.fillStyle = enabled ? (sel ? "#ffffff" : "#c9c9d2") : "#5c5c64";
    g.fillText(`${sel ? "▶" : ""}${label}`, x + w / 2, y + 2.5);
    g.restore();
  }

  drawHud(g: Ctx2D) {
    const id = this.cfg.id;
    // 敵名
    text(g, this.cfg.enemyName, 12, 30, { size: 9, color: "rgba(240,240,250,0.8)" });

    // ミケの囁き(画面右端に常時)
    const showWhisper = this.mode === "menu" || this.mode === "bar" || this.mode === "enemy";
    if (showWhisper) {
      drawMike(g, 262, 198, this.t * 2, 0.55, 0.95);
      rainbowText(g, `「${this.whisper()}」`, 176, 216, 8, this.t * 2);
    }

    // イントロテキスト
    if (this.mode === "intro") {
      const intro = this.cfg.intro ?? [];
      const cur = intro[this.introIdx];
      if (cur) {
        g.save();
        g.fillStyle = "rgba(6,6,12,0.88)";
        g.fillRect(14, 190, 292, 40);
        g.strokeStyle = "#f2f2f6";
        g.lineWidth = 1.5;
        g.strokeRect(15, 191, 290, 38);
        text(g, cur, 24, 200, { size: 10 });
        text(g, "Z▼", 286, 222, { size: 8, color: "#9a9aa2" });
        g.restore();
      }
    }

    // 戦況メッセージ
    if (this.feedback && performance.now() < this.feedback.until) {
      text(g, this.feedback.text, 12, 46, { size: 9, color: this.feedback.color });
    }

    // ゲート戦の水の底の声
    if (id === "gatekeepers" && (this.mode === "bar" || this.mode === "enemy")) {
      const mid = this.cfg.midText?.find((mm) => mm.turn === this.turn);
      if (mid) {
        const fl = 0.6 + Math.sin(this.t * 7) * 0.3;
        text(g, mid.text, 34, 60, { size: 11, color: `rgba(240,240,255,${0.5 + fl * 0.4})` });
      }
    }

    // 最終戦ルール表示
    if (id === "witch" && this.mode === "bar") {
      const lim = Math.max(1.6, 4 - this.turn * 0.25);
      const k = Math.min(1, this.autoT / lim);
      text(g, "Z:斬る(中央は絶対に押さない)", 34, 208, { size: 8, color: "#ffb0b0" });
      g.save();
      g.fillStyle = "rgba(255,90,90,0.8)";
      g.fillRect(34, 216, 120 * k, 2);
      g.restore();
      if (this.autoT > lim * 0.6) {
        rainbowText(g, "ミケが剣に手をかけている……!", 34, 196, 8, this.t * 3);
      }
    } else if (this.mode === "bar" && id !== "gatekeepers") {
      text(g, "Z:斬る", 34, 208, { size: 9, color: "#c9c9d2" });
    } else if (this.mode === "bar" && id === "gatekeepers") {
      text(g, "Z:斬る —— 三本目の白い線は、止まっている", 22, 214, { size: 8, color: "#c9c9d2" });
    }

    // HP数値
    text(g, `${this.hp}/${this.maxhp}`, 10, 32, { size: 8, color: "#ff8a9a" });

    // ハニー戦のカウント
    if (id === "honey" && this.spareArmed) {
      text(g, `耐える:${Math.min(3, this.survive)}/3`, 240, 12, { size: 9, color: "#ffe9c9" });
    }
    // 剥がれ段階
    if (id === "witch") {
      text(g, `色の剥がれ:${this.peels}/5`, 240, 52, { size: 8, color: "#dcdce6" });
    }

    // DEAD
    if (this.mode === "dead") {
      rainbowText(g, `ミケ「${this.deathLine}」`, 60, 110, 11, this.t * 2);
      if (this.modeT > 0.8) text(g, "Z:もう一度、同じ夜をやり直す", 78, 140, { size: 9, color: "#9a9aa2" });
    }

    // event(witch)ミケの絶叫
    if (this.mode === "event" && id === "witch") {
      rainbowText(g, "「やめるにゃ! 澪、斬るにゃ!!」", 46, 60, 11, this.t * 4);
    }
    if (this.mode === "event" && id === "gyorome") {
      text(g, "……影は、闇に溶けて消えた。", 70, 100, { size: 10, color: "#c9c9d2" });
    }
    if (this.mode === "event" && id === "honey") {
      text(g, "……最後のしずくが、口に落ちる。", 66, 100, { size: 10, color: "#ffe9c9" });
    }
  }
}
