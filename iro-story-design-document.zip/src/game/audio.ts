// ============================================================
// いろ — WebAudio による効果音とBGM生成(外部ファイル不使用)
// 現実=無音に近い環境音 / 向こう側=不協和音 / ED=あたたかい旋律
// ============================================================
import type { AudioSys } from "./types";

type Pattern = (step: number, time: number, ac: AudioContext, out: GainNode) => void;

const SCALE: Record<string, number> = {};
{
  // A3=220 を基準に半音テーブル
  const names = ["c", "c#", "d", "d#", "e", "f", "f#", "g", "g#", "a", "a#", "b"];
  for (let o = 1; o <= 7; o++) {
    for (let i = 0; i < 12; i++) {
      const midi = 12 * (o + 1) + i;
      SCALE[`${names[i]}${o}`] = 440 * Math.pow(2, (midi - 69) / 12);
    }
  }
}

class AudioImpl implements AudioSys {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private bgmGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private cur: string | null = null;
  private timer: number | null = null;
  private step = 0;
  private nextT = 0;
  private noiseBuf: AudioBuffer | null = null;

  unlock() {
    if (!this.ac) {
      try {
        this.ac = new AudioContext();
        this.master = this.ac.createGain();
        this.master.gain.value = 0.8;
        this.master.connect(this.ac.destination);
        this.bgmGain = this.ac.createGain();
        this.bgmGain.gain.value = 0.5;
        this.bgmGain.connect(this.master);
        this.sfxGain = this.ac.createGain();
        this.sfxGain.gain.value = 0.6;
        this.sfxGain.connect(this.master);
        const len = this.ac.sampleRate;
        this.noiseBuf = this.ac.createBuffer(1, len, this.ac.sampleRate);
        const d = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      } catch {
        this.ac = null;
      }
    }
    if (this.ac && this.ac.state === "suspended") {
      this.ac.resume().catch(() => undefined);
    }
  }

  private tone(
    freq: number, dur: number, t: number,
    type: OscillatorType = "sine", vol = 0.2,
    out?: GainNode, slideTo?: number
  ) {
    if (!this.ac) return;
    const ac = this.ac;
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(out ?? this.sfxGain ?? ac.destination);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private noise(dur: number, t: number, vol: number, fLow = 400, fHigh = 4000, out?: GainNode) {
    if (!this.ac || !this.noiseBuf) return;
    const ac = this.ac;
    const src = ac.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const bp = ac.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = Math.sqrt(fLow * fHigh);
    bp.Q.value = 0.8;
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(bp); bp.connect(g); g.connect(out ?? this.sfxGain ?? ac.destination);
    src.start(t); src.stop(t + dur + 0.05);
  }

  sfx(name: string) {
    if (!this.ac) return;
    this.unlock();
    if (!this.ac) return;
    const t = this.ac.currentTime + 0.01;
    switch (name) {
      case "text": this.tone(1180, 0.03, t, "square", 0.05); break;
      case "cursor": this.tone(740, 0.05, t, "square", 0.09); break;
      case "confirm": this.tone(660, 0.06, t, "square", 0.1); this.tone(990, 0.09, t + 0.06, "square", 0.09); break;
      case "cancel": this.tone(320, 0.09, t, "square", 0.09, undefined, 240); break;
      case "disabled": this.tone(180, 0.08, t, "square", 0.08); this.tone(160, 0.1, t + 0.08, "square", 0.08); break;
      case "door": this.noise(0.22, t, 0.12, 200, 900); break;
      case "step": this.noise(0.05, t, 0.03, 300, 700); break;
      case "hurt": this.noise(0.2, t, 0.2, 200, 2000); this.tone(220, 0.18, t, "sawtooth", 0.1, undefined, 90); break;
      case "slash": this.noise(0.16, t, 0.22, 3000, 9000); this.tone(1600, 0.12, t, "sawtooth", 0.06, undefined, 300); break;
      case "swing": this.noise(0.12, t, 0.12, 600, 2400); break;
      case "shatter": this.noise(0.4, t, 0.22, 4000, 12000); this.tone(1900, 0.3, t + 0.04, "triangle", 0.07, undefined, 900); break;
      case "drop": this.tone(880, 0.24, t, "sine", 0.12, undefined, 330); break;
      case "call": this.tone(880, 0.14, t, "sine", 0.13); this.tone(1108, 0.14, t + 0.15, "sine", 0.12); this.tone(1318, 0.3, t + 0.3, "sine", 0.12); break;
      case "steps_run": for (let i = 0; i < 5; i++) this.noise(0.06, t + i * 0.11, 0.1 - i * 0.012, 250, 800); break;
      case "get": [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.16, t + i * 0.09, "triangle", 0.1)); break;
      case "nyaa": this.tone(620, 0.16, t, "triangle", 0.1, undefined, 860); this.tone(860, 0.2, t + 0.13, "triangle", 0.09, undefined, 480); break;
      case "whiteout": this.noise(1.4, t, 0.16, 600, 6000); this.tone(220, 1.3, t, "sine", 0.06, undefined, 880); break;
      case "crack": this.noise(0.5, t, 0.24, 900, 5000); this.tone(140, 0.4, t, "sawtooth", 0.08, undefined, 60); break;
      case "heart_break": this.tone(520, 0.24, t, "square", 0.12, undefined, 120); this.noise(0.3, t + 0.1, 0.16, 300, 2400); break;
      case "whisper": this.noise(0.4, t, 0.05, 1200, 5200); break;
      case "hourglass": this.tone(1560, 0.04, t, "square", 0.05); break;
    }
  }

  bgm(name: string | null, fadeMs = 500) {
    this.unlock();
    if (!this.ac) { this.cur = name; return; }
    if (this.cur === name) return;
    this.cur = name;
    const ac = this.ac;
    if (this.timer !== null) { clearInterval(this.timer); this.timer = null; }
    if (this.bgmGain) {
      const g = this.bgmGain.gain;
      g.cancelScheduledValues(ac.currentTime);
      g.setValueAtTime(g.value, ac.currentTime);
      g.linearRampToValueAtTime(0.0001, ac.currentTime + fadeMs / 1000);
    }
    if (!name) return;
    const prevGain = this.bgmGain;
    setTimeout(() => {
      if (!this.ac || this.cur !== name || !prevGain) return;
      prevGain.gain.cancelScheduledValues(ac.currentTime);
      prevGain.gain.setValueAtTime(0.0001, ac.currentTime);
      prevGain.gain.linearRampToValueAtTime(this.level(name), ac.currentTime + 0.8);
    }, fadeMs);
    this.step = 0;
    this.nextT = ac.currentTime + 0.1;
    const stepDur = this.stepDur(name);
    const pat = PATTERNS[name];
    if (!pat) return;
    this.timer = window.setInterval(() => {
      if (!this.ac || !this.bgmGain) return;
      while (this.nextT < this.ac.currentTime + 0.18) {
        if (this.cur === name) pat(this.step, this.nextT, this.ac, this.bgmGain);
        this.step++;
        this.nextT += stepDur;
      }
    }, 70);
  }

  private level(name: string): number {
    switch (name) {
      case "real": return 0.16;
      case "realWarm": return 0.4;
      case "title": return 0.4;
      case "other": return 0.42;
      case "battle": return 0.45;
      case "final": return 0.42;
      case "ending": return 0.46;
      case "bad": return 0.36;
      default: return 0.4;
    }
  }
  private stepDur(name: string): number {
    switch (name) {
      case "battle": return 0.13;
      case "other": return 0.19;
      case "final": return 0.24;
      case "ending": return 0.21;
      default: return 0.26;
    }
  }
}

const PATTERNS: Record<string, Pattern> = {
  // タイトル:静かな病棟 + かすかな色彩
  title: (s, t, ac, out) => {
    const mel = ["a3", "c4", "e4", "d4", "a3", "f4", "e4", "c4"];
    if (s % 4 === 0) pluck(ac, out, SCALE[mel[(s / 4) % 8 | 0]], t, 0.09);
    if (s % 16 === 8) pluck(ac, out, SCALE["g4"], t, 0.05);
    pad(ac, out, [SCALE["a2"], SCALE["e3"]], t, 0.5, 2.1);
  },
  // 現実:ほぼ無音。時計と空気
  real: (s, t, ac, out) => {
    if (s % 8 === 0) tickTock(ac, out, t);
    pad(ac, out, [SCALE["a1"], SCALE["a1"] * 1.007], t, 0.028, 2.2);
  },
  // 現実(あたたかさが戻りはじめ)
  realWarm: (s, t, ac, out) => {
    if (s % 8 === 0) tickTock(ac, out, t, 0.5);
    pad(ac, out, [SCALE["c3"], SCALE["g3"], SCALE["e3"]], t, 0.035, 1.9);
    const mel = ["e4", "g4", "a4", "g4", "e4", "c4", "d4", "e4"];
    if (s % 8 === 2 && Math.floor(s / 8) % 2 === 0) pluck(ac, out, SCALE[mel[(s / 8 / 2) % 8 | 0]] ?? 440, t, 0.05, 1.4);
  },
  // 向こう側:不協和な夢
  other: (s, t, ac, out) => {
    const seq = ["d4", "d#4", "a4", "b3", "d4", "f4", "c#5", "d4"];
    const f = SCALE[seq[s % 8]];
    pluck(ac, out, f, t, 0.07);
    if (s % 8 === 4) pluck(ac, out, f * 1.02, t + 0.06, 0.05);
    pad(ac, out, [SCALE["d3"], SCALE["d#3"] * 0.5 * 2], t, 0.05, 1.6, "sawtooth");
    if (s % 32 === 0) bellIn(ac, out, SCALE["a2"] * 0.5, t, 0.1);
  },
  // 戦闘:鼓動
  battle: (s, t, ac, out) => {
    if (s % 2 === 0) kick(ac, out, t);
    const seq = ["a3", "c4", "d4", "e4", "a3", "e4", "d4", "c4"];
    pluck(ac, out, SCALE[seq[s % 8]] * 2, t, 0.06, 0.5, "square");
    pad(ac, out, [SCALE["a2"]], t, 0.05, 0.9, "sawtooth");
  },
  // 最終戦:鐘と緊張
  final: (s, t, ac, out) => {
    if (s % 16 === 0) bellIn(ac, out, SCALE["a2"], t, 0.16);
    if (s % 16 === 10) bellIn(ac, out, SCALE["a#2"], t, 0.1);
    const seq = ["e4", "f4", "c5", "b4", "e4", "a4", "g#4", "a4"];
    if (s % 2 === 0) pluck(ac, out, SCALE[seq[(s / 2) % 8 | 0]], t, 0.05, 0.7, "triangle");
    pad(ac, out, [SCALE["a1"], SCALE["e2"]], t, 0.05, 2.4);
  },
  // エンディング:色の戻った空
  ending: (s, t, ac, out) => {
    const seq = ["c4", "e4", "g4", "b4", "a4", "g4", "e4", "d4"];
    pluck(ac, out, SCALE[seq[s % 8]], t, 0.08, 1.2, "triangle");
    pad(ac, out, [SCALE["c3"], SCALE["g3"], SCALE["e4"] * 0.5], t, 0.045, 2.2);
    if (s % 32 === 16) bellIn(ac, out, SCALE["g4"], t, 0.05);
  },
  // バッド:低いドローン
  bad: (s, t, ac, out) => {
    pad(ac, out, [SCALE["a1"], SCALE["a#1"] * 1.01], t, 0.07, 3.2, "sawtooth");
    if (s % 24 === 8) bellIn(ac, out, SCALE["d3"], t, 0.08);
    if (s % 40 === 20) bellIn(ac, out, SCALE["c#3"], t, 0.06);
  },
};

function pluck(ac: AudioContext, out: GainNode, freq: number, t: number, vol: number, dur = 0.8, type: OscillatorType = "triangle") {
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol, t + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(out);
  o.start(t); o.stop(t + dur + 0.05);
}
function pad(ac: AudioContext, out: GainNode, freqs: number[], t: number, vol: number, dur = 2, type: OscillatorType = "sine") {
  for (const f of freqs) {
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol / freqs.length, t + dur * 0.4);
    g.gain.linearRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(out);
    o.start(t); o.stop(t + dur + 0.1);
  }
}
function bellIn(ac: AudioContext, out: GainNode, freq: number, t: number, vol: number) {
  for (const [m, v] of [[1, 1], [2.4, 0.4], [5.1, 0.2]] as const) {
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = "sine";
    o.frequency.value = freq * m;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol * v, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
    o.connect(g); g.connect(out);
    o.start(t); o.stop(t + 2);
  }
}
function kick(ac: AudioContext, out: GainNode, t: number) {
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = "sine";
  o.frequency.setValueAtTime(150, t);
  o.frequency.exponentialRampToValueAtTime(40, t + 0.12);
  g.gain.setValueAtTime(0.3, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
  o.connect(g); g.connect(out);
  o.start(t); o.stop(t + 0.2);
}
function tickTock(ac: AudioContext, out: GainNode, t: number, vol = 1) {
  const src = ac.createBufferSource();
  const len = ac.sampleRate * 0.03;
  const buf = ac.createBuffer(1, len, ac.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  src.buffer = buf;
  const f = ac.createBiquadFilter();
  f.type = "highpass";
  f.frequency.value = 1800;
  const g = ac.createGain();
  g.gain.value = 0.14 * vol;
  src.connect(f); f.connect(g); g.connect(out);
  src.start(t);
}

export const audioSys: AudioSys = new AudioImpl();
