// ============================================================
// いろ — 共有型定義
// ============================================================

export type Ctx2D = CanvasRenderingContext2D;
export type Side = "real" | "other";
export type FaceDir = "down" | "up" | "left" | "right";
export type KeyName = "up" | "down" | "left" | "right" | "z" | "x" | "c";

export interface Scene {
  done: boolean;
  enter?(): void;
  exit?(): void;
  update(dt: number): void;
  draw(g: Ctx2D): void; // 320x240 バッファ
  drawHud?(g: Ctx2D): void; // ディスプレイ(320x240 座標・文字はくっきり)
}

export interface Input {
  held(k: KeyName): boolean;
  consume(k: KeyName): boolean;
  peek(k: KeyName): boolean;
}

export interface Assets {
  has(name: string): boolean;
  img(name: string): HTMLImageElement | null;
}

export interface AudioSys {
  unlock(): void;
  sfx(name: string): void;
  bgm(name: string | null, fadeMs?: number): void;
}

export interface SaveData {
  v: number;
  checkpoint: string;
  seenBad: number[];
  unlockedCall: boolean;
  cleared: boolean;
}
export interface SaveSys {
  d: SaveData;
  commit(): void;
  load(): void;
  wipeRun(): void;
}

export interface SayOpt {
  mike?: boolean;
  color?: string;
}
export interface ChoiceOpt {
  label: string;
  disabled?: boolean;
  note?: string;
}
export type Line = [string | null, string];

export interface UI {
  say(name: string | null, text: string, opt?: SayOpt): Promise<void>;
  narr(text: string): Promise<void>;
  lines(arr: Line[], opt?: SayOpt): Promise<void>;
  choice(opts: ChoiceOpt[], title?: string): Promise<number>;
  toast(text: string, ms?: number): void;
  objective(text: string | null): void;
  setGauge(v: number | null): void;
  hideBox(): void;
  busy(): boolean;
}

export interface FX {
  fadeOut(color: string, ms: number): Promise<void>;
  fadeIn(ms: number): Promise<void>;
  bleed(mid: () => void, ms?: number): Promise<void>;
  shake(amp: number, ms: number): void;
  flash(color: string, ms: number): void;
  sat(v: number): void; // 100=通常 0=モノクロ (-1で解除)
}

export interface StageChar {
  id: string;
  x?: number;
  variant?: string;
  alpha?: number;
}
export interface Stage {
  show: boolean;
  bg: string;
  other: boolean;
  dark: number;
  chars: StageChar[];
  props: string[];
  setBg(bg: string, other?: boolean): void;
  setChars(list: StageChar[]): void;
  setProps(list: string[]): void;
  reset(): void;
}

export interface SceneRunner {
  run<T extends Scene>(s: T): Promise<T>;
}

export interface Game {
  W: number;
  H: number;
  input: Input;
  assets: Assets;
  audio: AudioSys;
  save: SaveSys;
  ui: UI;
  fx: FX;
  stage: Stage;
  scenes: SceneRunner;
  now: number;
}

// ---------------- 戦闘 ----------------
export type BattleId = "gyorome" | "honey" | "gatekeepers" | "witch";
export interface BattleConfig {
  id: BattleId;
  enemyName: string;
  canSpare: boolean;
  spareNote?: string;
  whispers: string[];
  intro?: string[];
  midText?: { turn: number; text: string; garble?: boolean }[];
}
export type BattleResult = "fought" | "spared" | "cut3" | "crit" | "cleansed" | null;

// ---------------- 探索 ----------------
export interface ExploreMarker {
  id: string;
  map: string;
  x: number;
  y: number;
}
export interface ExploreAPI {
  ripeness: number;
  allowCall: boolean;
  setObjective(t: string): void;
  setMarkers(m: ExploreMarker[]): void;
  setRipeRate(r: number): void;
  callFlash(): void;
  finish(): void;
}
export interface ExploreConfig {
  side: Side;
  startMap: string;
  spawn: [number, number];
  dir?: FaceDir;
  objective: string;
  markers: ExploreMarker[];
  ripeness: number | null;
  ripeRate?: number;
  time?: "day" | "evening" | "night";
  allowCall?: boolean;
  hanaLines?: Line[];
  onMarker?(id: string, api: ExploreAPI): Promise<boolean>;
  onCall?(api: ExploreAPI): Promise<boolean>;
  onRipeFull?(api: ExploreAPI): Promise<void>;
  onExamine?(propId: string, api: ExploreAPI): Promise<void>;
}
