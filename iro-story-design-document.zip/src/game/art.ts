// ============================================================
// いろ — プロシージャルアート(素材PNGがあればそちらが優先される)
// 現実=モノクロ / 向こう側=極彩色 を原則とする
// ============================================================
import type { Ctx2D, FaceDir, Side } from "./types";
import { TILE, type GameMap, tileAt } from "./maps";

export const FONT = '"Hiragino Sans","Hiragino Kaku Gothic ProN","Yu Gothic UI","Noto Sans JP",sans-serif';

export function text(
  g: Ctx2D, s: string, x: number, y: number,
  opt: { color?: string; size?: number; align?: CanvasTextAlign; alpha?: number } = {}
) {
  g.save();
  g.font = `${opt.size ?? 10}px ${FONT}`;
  g.textAlign = opt.align ?? "left";
  g.textBaseline = "top";
  g.globalAlpha = opt.alpha ?? 1;
  g.fillStyle = opt.color ?? "#f2f2f6";
  g.fillText(s, x, y);
  g.restore();
}

export function textW(g: Ctx2D, s: string, size = 10): number {
  g.save();
  g.font = `${size}px ${FONT}`;
  const w = g.measureText(s).width;
  g.restore();
  return w;
}

export const RAINBOW = ["#ff5a5a", "#ffb84d", "#f5e94e", "#66e06a", "#4fc3ff", "#b07dff", "#ff7dd2"];
export function rainbowText(g: Ctx2D, s: string, x: number, y: number, size = 10, t = 0) {
  g.save();
  g.font = `${size}px ${FONT}`;
  g.textBaseline = "top";
  let cx = x;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    g.fillStyle = RAINBOW[(i + Math.floor(t * 4)) % RAINBOW.length];
    g.fillText(ch, cx, y);
    cx += g.measureText(ch).width;
  }
  g.restore();
}

// ---------------- タイル描画 ----------------
const PAL = {
  real: {
    floor: "#d8d8dc", floorAlt: "#cfcfd4", grid: "#c4c4c9",
    wallT: "#f0f0f2", wallF: "#b9b9be", wallD: "#9e9ea4",
    bed: "#f4f4f6", bedFrame: "#a5a5ab", table: "#b4b4ba", chair: "#adadb3",
    shelf: "#9d9da3", plant: "#bdbdc2", plantPot: "#8c8c92",
    counter: "#c6c6cb", vend: "#b0b0b6", tv: "#8f8f95",
    fence: "#b6b6bb", flower: "#c9c9ce", tree: "#a9a9ae", trunk: "#8e8e94",
    grass: "#d2d2d6", window: "#f7f7f9",
  },
  other: {
    floor: "#3d0f52", floorAlt: "#2b0b3b", grid: "#e040fb",
    wallT: "#a3123f", wallF: "#5c1030", wallD: "#3b0a20",
    bed: "#8ffd32", bedFrame: "#ff3d8a", table: "#ffb300", chair: "#ff6a13",
    shelf: "#00e5ff", plant: "#7Cff4f", plantPot: "#ff2fd0",
    counter: "#ffd93a", vend: "#00ffc8", tv: "#b7ff2e",
    fence: "#ff7a1a", flower: "#ff4fa0", tree: "#59ff8e", trunk: "#ff8b3d",
    grass: "#1dd6a0", window: "#ffe14d",
  },
};

export function drawTiles(g: Ctx2D, m: GameMap, side: Side, camX: number, camY: number) {
  const P = PAL[side];
  const x0 = Math.max(0, Math.floor(camX / TILE));
  const y0 = Math.max(0, Math.floor(camY / TILE));
  const x1 = Math.min(m.w - 1, Math.ceil((camX + 320) / TILE));
  const y1 = Math.min(m.h - 1, Math.ceil((camY + 240) / TILE));
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const ch = tileAt(m, x, y);
      const px = x * TILE - camX;
      const py = y * TILE - camY;
      const grass = m.id === "courtyard";
      // 床
      if (ch !== "#" && ch !== "F") {
        g.fillStyle = (x + y) % 2 === 0 ? (grass ? P.grass : P.floor) : (grass ? shade(P.grass, -8) : P.floorAlt);
        g.fillRect(px, py, TILE, TILE);
        if (!grass && (x + y) % 3 === 0) {
          g.fillStyle = P.grid;
          g.fillRect(px, py + TILE - 1, TILE, 1);
        }
        if (side === "other") {
          g.fillStyle = "rgba(224,64,251,0.08)";
          g.fillRect(px, py, TILE, 1);
          g.fillRect(px, py, 1, TILE);
        }
      }
      switch (ch) {
        case "#": {
          // 壁(下面が床なら立面)
          const below = tileAt(m, x, y + 1);
          if (below !== "#" && below !== "F") {
            g.fillStyle = P.wallF;
            g.fillRect(px, py, TILE, TILE);
            g.fillStyle = P.wallD;
            g.fillRect(px, py + TILE - 2, TILE, 2);
            g.fillStyle = side === "other" ? "rgba(255,64,160,0.25)" : "rgba(255,255,255,0.5)";
            g.fillRect(px, py, TILE, 1);
          } else {
            g.fillStyle = P.wallT;
            g.fillRect(px, py, TILE, TILE);
            g.fillStyle = shade(P.wallT, -6);
            g.fillRect(px, py + TILE - 1, TILE, 1);
          }
          break;
        }
        case "F":
          g.fillStyle = P.fence;
          g.fillRect(px, py + 6, TILE, 3);
          g.fillRect(px + 2, py + 2, 3, TILE - 3);
          g.fillRect(px + 11, py + 2, 3, TILE - 3);
          break;
        case "W": {
          g.fillStyle = P.wallF;
          g.fillRect(px, py, TILE, TILE);
          g.fillStyle = P.window;
          g.fillRect(px + 2, py + 3, TILE - 4, TILE - 6);
          if (side === "other") {
            const grd = g.createLinearGradient(px, py, px + TILE, py + TILE);
            grd.addColorStop(0, "#ff5d3a");
            grd.addColorStop(1, "#ffc93a");
            g.fillStyle = grd;
            g.fillRect(px + 3, py + 4, TILE - 6, TILE - 8);
          }
          g.fillStyle = P.wallD;
          g.fillRect(px + TILE / 2 - 1, py + 3, 2, TILE - 6);
          break;
        }
        case "B": {
          const above = tileAt(m, x, y - 1);
          g.fillStyle = P.bedFrame;
          g.fillRect(px + 1, py + 2, TILE - 2, TILE - 3);
          g.fillStyle = P.bed;
          g.fillRect(px + 2, py + 3, TILE - 4, TILE - 5);
          if (above !== "B") {
            g.fillStyle = shade(P.bed, -14);
            g.fillRect(px + 3, py + 4, TILE - 6, 4);
          }
          break;
        }
        case "T":
          g.fillStyle = P.table;
          rr(g, px + 1, py + 4, TILE - 2, TILE - 7, 2);
          g.fillStyle = shade(P.table, 10);
          g.fillRect(px + 3, py + 6, TILE - 6, 2);
          break;
        case "C":
          g.fillStyle = P.chair;
          rr(g, px + 3, py + 4, TILE - 6, TILE - 7, 2);
          g.fillStyle = shade(P.chair, -12);
          g.fillRect(px + 3, py + 4, TILE - 6, 2);
          break;
        case "S":
          g.fillStyle = P.shelf;
          rr(g, px, py + 1, TILE, TILE - 1, 1);
          g.fillStyle = shade(P.shelf, -14);
          g.fillRect(px + 2, py + 5, TILE - 4, 2);
          g.fillRect(px + 2, py + 10, TILE - 4, 2);
          // 封筒
          g.fillStyle = side === "other" ? "#ffe14d" : "#f2f2f4";
          g.fillRect(px + 3, py + 10, 7, 4);
          break;
        case "P":
          g.fillStyle = P.plantPot;
          rr(g, px + 4, py + 9, 8, 6, 1);
          g.fillStyle = P.plant;
          g.beginPath();
          g.arc(px + 5, py + 7, 4, 0, Math.PI * 2);
          g.arc(px + 10, py + 6, 4, 0, Math.PI * 2);
          g.arc(px + 8, py + 9, 3, 0, Math.PI * 2);
          g.fill();
          break;
        case "N":
        case "Q":
          g.fillStyle = P.counter;
          g.fillRect(px, py + 5, TILE, TILE - 5);
          g.fillStyle = shade(P.counter, 12);
          g.fillRect(px, py + 5, TILE, 2);
          if (ch === "Q") {
            g.fillStyle = "rgba(255,255,255,0.25)";
            g.fillRect(px + 2, py + 2, TILE - 4, 2);
          }
          break;
        case "V":
          g.fillStyle = P.vend;
          rr(g, px + 1, py, TILE - 2, TILE + 2, 2);
          g.fillStyle = side === "other" ? "#00ffc8" : "#e9e9ec";
          g.fillRect(px + 3, py + 3, TILE - 6, 6);
          g.fillStyle = shade(P.vend, -20);
          g.fillRect(px + 3, py + 11, TILE - 6, 3);
          break;
        case "K":
          g.fillStyle = P.tv;
          rr(g, px, py + 2, TILE, TILE - 5, 2);
          g.fillStyle = side === "other" ? "#b7ff2e" : "#d9d9de";
          g.fillRect(px + 2, py + 4, TILE - 4, TILE - 9);
          break;
        case "R":
          g.fillStyle = P.wallF;
          g.fillRect(px, py, TILE, TILE);
          g.fillStyle = shade(P.wallF, -20);
          rr(g, px + 3, py + 2, TILE - 6, TILE - 2, 1);
          g.fillStyle = "#dadade";
          g.fillRect(px + 11, py + 8, 2, 2);
          break;
        case "~":
          g.fillStyle = P.flower;
          for (let i = 0; i < 5; i++) {
            const fx = px + 2 + ((i * 53) % 12);
            const fy = py + 4 + ((i * 37) % 9);
            g.beginPath();
            g.arc(fx, fy, 2, 0, Math.PI * 2);
            g.fill();
          }
          break;
        case "G": {
          const above = tileAt(m, x, y - 1);
          if (above !== "G") {
            g.fillStyle = P.tree;
            g.beginPath();
            g.arc(px + 8, py + 5, 9, 0, Math.PI * 2);
            g.fill();
            g.fillStyle = shade(P.tree, 12);
            g.beginPath();
            g.arc(px + 5, py + 3, 4, 0, Math.PI * 2);
            g.fill();
          } else {
            g.fillStyle = P.trunk;
            g.fillRect(px + 6, py, 4, TILE);
          }
          break;
        }
        case "D":
          g.fillStyle = shade(P.wallD, side === "other" ? 20 : -4);
          g.fillRect(px, py, TILE, TILE);
          g.fillStyle = "rgba(0,0,0,0.25)";
          g.fillRect(px + 2, py + 2, TILE - 4, TILE - 2);
          break;
      }
    }
  }
}

export function shade(hex: string, amt: number): string {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) + amt, gg = ((n >> 8) & 0xff) + amt, b = (n & 0xff) + amt;
  r = Math.max(0, Math.min(255, r));
  gg = Math.max(0, Math.min(255, gg));
  b = Math.max(0, Math.min(255, b));
  return `rgb(${r},${gg},${b})`;
}

export function rr(g: Ctx2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
  g.fill();
}

// ---------------- キャラ(16x24) ----------------
export interface PersonOpt {
  hair: string;
  cloth: string;
  trim?: string;
  skin?: string;
  frame: number; // 0:直立 1/2:歩行
  dir: FaceDir;
  gauze?: boolean;
  wound?: boolean; // 頬の傷(モノクロ世界の唯一の赤)
  alpha?: number;
  long?: boolean; // ロングヘア
}
export function drawPerson(g: Ctx2D, x: number, y: number, o: PersonOpt) {
  const skin = o.skin ?? "#e3e3e6";
  const trim = o.trim ?? o.cloth;
  g.save();
  g.globalAlpha = o.alpha ?? 1;
  const bob = o.frame === 0 ? 0 : o.frame === 1 ? -1 : 0;
  // 足
  g.fillStyle = shade(o.cloth, -50);
  if (o.frame === 1) {
    g.fillRect(x + 4, y + 20, 3, 4);
    g.fillRect(x + 9, y + 19, 3, 4);
  } else if (o.frame === 2) {
    g.fillRect(x + 4, y + 19, 3, 4);
    g.fillRect(x + 9, y + 20, 3, 4);
  } else {
    g.fillRect(x + 4, y + 19, 3, 5);
    g.fillRect(x + 9, y + 19, 3, 5);
  }
  // 体
  g.fillStyle = o.cloth;
  rr(g, x + 3, y + 9 + bob, 10, 11, 2);
  g.fillStyle = trim;
  g.fillRect(x + 3, y + 9 + bob, 10, 2);
  // 腕
  g.fillStyle = shade(o.cloth, -16);
  const swing = o.frame === 1 ? 1 : o.frame === 2 ? -1 : 0;
  g.fillRect(x + 1, y + 10 + bob + swing, 2, 7);
  g.fillRect(x + 13, y + 10 + bob - swing, 2, 7);
  // 頭
  g.fillStyle = skin;
  rr(g, x + 3, y + 1 + bob, 10, 9, 3);
  // 髪
  g.fillStyle = o.hair;
  if (o.dir === "up") {
    rr(g, x + 2, y + bob, 12, 8, 3);
    if (o.long) g.fillRect(x + 2, y + 6 + bob, 12, 6);
  } else {
    rr(g, x + 2, y + bob, 12, 5, 3);
    g.fillRect(x + 2, y + 2 + bob, 2, 5);
    g.fillRect(x + 12, y + 2 + bob, 2, 5);
    if (o.long) {
      g.fillRect(x + 2, y + 5 + bob, 3, 7);
      g.fillRect(x + 11, y + 5 + bob, 3, 7);
    }
    // 目
    g.fillStyle = "#26262b";
    if (o.dir === "left") {
      g.fillRect(x + 4, y + 5 + bob, 2, 2);
    } else if (o.dir === "right") {
      g.fillRect(x + 10, y + 5 + bob, 2, 2);
    } else {
      g.fillRect(x + 5, y + 5 + bob, 2, 2);
      g.fillRect(x + 10, y + 5 + bob, 2, 2);
    }
  }
  if (o.gauze && o.dir !== "up") {
    g.fillStyle = "#f6f6f8";
    g.fillRect(x + 3, y + 4 + bob, 4, 3);
  }
  if (o.wound) {
    g.fillStyle = "#c0161f"; // モノクロ世界で唯一の赤
    g.fillRect(x + 10, y + 6 + bob, 3, 1);
    g.fillRect(x + 11, y + 7 + bob, 3, 1);
  }
  g.restore();
}

// キャラ定義(現実=モノクロ配色)
export const CHARPAL: Record<string, PersonOpt> = {
  mio_real: { hair: "#3a3a3f", cloth: "#e8e8ec", trim: "#c9c9cf", skin: "#e6e6e9", frame: 0, dir: "down" },
  mio_other: { hair: "#51306e", cloth: "#ffe74d", trim: "#ff5a9e", skin: "#ffd9c0", frame: 0, dir: "down" },
  kaede: { hair: "#2c2c30", cloth: "#f4f4f6", trim: "#c2c2c8", skin: "#e3e3e6", frame: 0, dir: "down" },
  kaede_gauze: { hair: "#2c2c30", cloth: "#f4f4f6", trim: "#c2c2c8", skin: "#e3e3e6", frame: 0, dir: "down", gauze: true },
  kaede_wound: { hair: "#2c2c30", cloth: "#f0f0f2", trim: "#b9b9bf", skin: "#e0e0e3", frame: 0, dir: "down", wound: true },
  mother: { hair: "#4a4a4f", cloth: "#b9b9c0", trim: "#9d9da4", skin: "#e3e3e6", frame: 0, dir: "down", long: true },
  doctor: { hair: "#58585e", cloth: "#f0f0f2", trim: "#5c5c62", skin: "#e3e3e6", frame: 0, dir: "down" },
  nurse_night: { hair: "#333338", cloth: "#ececf0", trim: "#c2c2c8", skin: "#e3e3e6", frame: 0, dir: "down" },
  staff_meal: { hair: "#3f3f45", cloth: "#dcdce0", trim: "#f4f4f6", skin: "#e3e3e6", frame: 0, dir: "down" },
  hana: { hair: "#8b8b91", cloth: "#cfcfd5", trim: "#b2b2b9", skin: "#e6e6e9", frame: 0, dir: "down" },
};

export function drawCharLarge(g: Ctx2D, id: string, cx: number, baseY: number, alpha = 1) {
  const p = CHARPAL[id] ?? CHARPAL.mio_real;
  const sc = 4;
  g.save();
  g.globalAlpha = alpha;
  g.translate(cx - 8 * sc, baseY - 24 * sc);
  g.scale(sc, sc);
  drawPerson(g, 0, 0, { ...p, frame: 0, dir: "down" });
  g.restore();
}

// ---------------- ミケ ----------------
export function drawMike(g: Ctx2D, x: number, y: number, t = 0, scale = 1, alpha = 1) {
  g.save();
  g.translate(x, y);
  g.scale(scale, scale);
  g.globalAlpha = alpha;
  const tail = Math.sin(t * 3) * 2;
  // しっぽ
  g.strokeStyle = "#ff7dd2";
  g.lineWidth = 2.4;
  g.beginPath();
  g.moveTo(24, 22);
  g.quadraticCurveTo(31, 18 + tail, 29, 11 + tail);
  g.stroke();
  // 体
  const patches = ["#ff5a5a", "#ffb84d", "#66e06a"];
  g.fillStyle = "#fdfdfd";
  rr(g, 5, 12, 21, 14, 6);
  g.fillStyle = patches[0];
  rr(g, 7, 14, 7, 6, 3);
  g.fillStyle = patches[1];
  rr(g, 16, 18, 7, 5, 2);
  // 頭
  g.fillStyle = "#fdfdfd";
  rr(g, 2, 2, 17, 13, 5);
  // 耳
  g.beginPath();
  g.moveTo(4, 4); g.lineTo(6, -1); g.lineTo(9, 3);
  g.moveTo(14, 3); g.lineTo(17, -1); g.lineTo(18, 4);
  g.fill();
  g.fillStyle = "#b07dff";
  rr(g, 11, 3, 7, 6, 2);
  // ガラス玉の目
  const blink = Math.sin(t * 1.7) > 0.97 ? 0.3 : 1;
  for (const ex of [7, 14]) {
    g.fillStyle = "#ffffff";
    g.beginPath();
    g.arc(ex, 8.5, 2.6, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#0e0e18";
    g.beginPath();
    g.ellipse(ex, 8.5, 1.4, 2.2 * blink, 0, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#ffffff";
    g.fillRect(ex - 1, 7, 1, 1);
  }
  g.fillStyle = "#ff7dd2";
  g.fillRect(10, 11, 2, 1);
  g.restore();
}

// ---------------- 敵 ----------------
export function drawGyorome(g: Ctx2D, cx: number, cy: number, t: number, alpha = 1) {
  g.save();
  g.globalAlpha = alpha;
  // 影の本体
  g.fillStyle = "#16001f";
  g.beginPath();
  for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.28) {
    const r = 40 + Math.sin(a * 5 + t * 2.2) * 5 + Math.cos(a * 3 - t * 1.6) * 4;
    const px = cx + Math.cos(a) * r;
    const py = cy + Math.sin(a) * r * 0.92;
    if (a === 0) g.moveTo(px, py);
    else g.lineTo(px, py);
  }
  g.closePath();
  g.fill();
  g.strokeStyle = "rgba(190,80,255,0.5)";
  g.lineWidth = 1.5;
  g.stroke();
  // たくさんの目
  const eyes = [
    [-18, -10, 8], [10, -18, 9], [22, 2, 7], [-4, 6, 11],
    [-24, 12, 7], [8, 20, 8], [26, -22, 5], [-8, -24, 6], [-30, -2, 5],
  ];
  const look = { x: Math.sin(t * 0.9) * 1.6, y: Math.cos(t * 0.7) * 1.4 };
  for (let i = 0; i < eyes.length; i++) {
    const [ex, ey, er] = eyes[i];
    const blink = Math.sin(t * 1.4 + i * 1.9) > 0.93 ? 0.25 : 1;
    g.fillStyle = "#f4f4ff";
    g.beginPath();
    g.ellipse(cx + ex, cy + ey, er, er * blink, 0, 0, Math.PI * 2);
    g.fill();
    if (blink > 0.5) {
      g.fillStyle = "#0a0012";
      g.beginPath();
      g.arc(cx + ex + look.x, cy + ey + look.y, er * 0.45, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#ff4fd8";
      g.beginPath();
      g.arc(cx + ex + look.x + 1, cy + ey + look.y - 1, er * 0.15, 0, Math.PI * 2);
      g.fill();
    }
  }
  g.restore();
}

export function drawHoneyQueen(g: Ctx2D, cx: number, cy: number, t: number, alpha = 1) {
  g.save();
  g.globalAlpha = alpha;
  const flap = Math.sin(t * 18) * 0.7;
  // 羽
  g.fillStyle = "rgba(255,255,255,0.38)";
  g.save();
  g.translate(cx - 12, cy - 22);
  g.rotate(-0.5 - flap * 0.3);
  g.beginPath(); g.ellipse(-12, 0, 18, 8, 0, 0, Math.PI * 2); g.fill();
  g.restore();
  g.save();
  g.translate(cx + 12, cy - 22);
  g.rotate(0.5 + flap * 0.3);
  g.beginPath(); g.ellipse(12, 0, 18, 8, 0, 0, Math.PI * 2); g.fill();
  g.restore();
  // 体(金装飾)
  const grad = g.createLinearGradient(cx, cy - 40, cx, cy + 42);
  grad.addColorStop(0, "#ffdf5e");
  grad.addColorStop(1, "#c47a00");
  g.fillStyle = grad;
  g.beginPath();
  g.ellipse(cx, cy, 26, 40, 0, 0, Math.PI * 2);
  g.fill();
  // 縞
  g.fillStyle = "#5b3200";
  for (let i = 0; i < 3; i++) {
    const yy = cy - 6 + i * 14;
    g.beginPath();
    g.ellipse(cx, yy, 26 - i * 4, 5, 0, 0, Math.PI * 2);
    g.fill();
  }
  // 頭
  g.fillStyle = "#ffd95e";
  g.beginPath();
  g.arc(cx, cy - 34, 13, 0, Math.PI * 2);
  g.fill();
  // 触角
  g.strokeStyle = "#5b3200";
  g.lineWidth = 2;
  g.beginPath();
  g.moveTo(cx - 5, cy - 44); g.quadraticCurveTo(cx - 12, cy - 56, cx - 8, cy - 60);
  g.moveTo(cx + 5, cy - 44); g.quadraticCurveTo(cx + 12, cy - 56, cx + 8, cy - 60);
  g.stroke();
  // 王冠(蜜)
  g.fillStyle = "#fff0a8";
  g.beginPath();
  g.moveTo(cx - 8, cy - 44);
  g.lineTo(cx - 8, cy - 52); g.lineTo(cx - 3, cy - 47);
  g.lineTo(cx, cy - 54); g.lineTo(cx + 3, cy - 47);
  g.lineTo(cx + 8, cy - 52); g.lineTo(cx + 8, cy - 44);
  g.closePath();
  g.fill();
  // 目
  g.fillStyle = "#2a1500";
  g.beginPath();
  g.arc(cx - 4, cy - 34, 2.4, 0, Math.PI * 2);
  g.arc(cx + 4, cy - 34, 2.4, 0, Math.PI * 2);
  g.fill();
  // 蜜の滴
  g.fillStyle = "rgba(255,196,30,0.9)";
  for (let i = 0; i < 4; i++) {
    const dx = [-18, 20, -6, 10][i];
    const ph = (t * 0.4 + i * 0.27) % 1;
    const dy = cy + 34 + ph * 22;
    g.beginPath();
    g.ellipse(cx + dx, dy, 2.6, 3.6, 0, 0, Math.PI * 2);
    g.fill();
  }
  g.restore();
}

export function drawGatekeeper(g: Ctx2D, cx: number, cy: number, t: number, small = false, alpha = 1, armsWide = false) {
  const H = small ? 64 : 128;
  const W = small ? 34 : 62;
  g.save();
  g.globalAlpha = alpha;
  g.shadowColor = "rgba(255,255,255,0.8)";
  g.shadowBlur = small ? 8 : 16;
  g.fillStyle = "#f6f6f8";
  const top = cy - H;
  // 体
  rr(g, cx - W / 2, top + H * 0.22, W, H * 0.78, W * 0.24);
  // 頭(のっぺり)
  g.beginPath();
  g.arc(cx, top + H * 0.13, W * 0.38, 0, Math.PI * 2);
  g.fill();
  // 腕
  g.shadowBlur = small ? 5 : 10;
  if (armsWide) {
    rr(g, cx - W * 1.15, top + H * 0.3, W * 0.7, H * 0.12, H * 0.06);
    rr(g, cx + W * 0.45, top + H * 0.3, W * 0.7, H * 0.12, H * 0.06);
  } else {
    const sway = Math.sin(t * 1.1) * 3;
    rr(g, cx - W / 2 - W * 0.16, top + H * 0.3 + sway, W * 0.16, H * 0.42, W * 0.08);
    rr(g, cx + W / 2, top + H * 0.3 - sway, W * 0.16, H * 0.42, W * 0.08);
  }
  g.restore();
}

export function drawWitch(g: Ctx2D, cx: number, cy: number, t: number, stage: number) {
  // stage 0(極彩色)→4(ほぼ白)
  const k = stage / 4; // 0..1
  const sat = (hexA: string, gray: string) => mix(hexA, gray, k);
  g.save();
  // 影の衣
  g.fillStyle = mix("#1b1030", "#d9d9de", k * 0.85);
  g.beginPath();
  g.moveTo(cx - 52, cy + 80);
  g.quadraticCurveTo(cx - 46, cy - 20, cx - 16, cy - 34);
  g.lineTo(cx + 16, cy - 34);
  g.quadraticCurveTo(cx + 46, cy - 20, cx + 52, cy + 80);
  g.closePath();
  g.fill();
  // 腕
  g.fillStyle = mix("#241840", "#cfcfd6", k * 0.85);
  rr(g, cx - 58, cy + 6 + Math.sin(t * 1.3) * 3, 18, 52, 9);
  rr(g, cx + 40, cy + 6 - Math.sin(t * 1.3) * 3, 18, 52, 9);
  // 頭の大鍋
  const potR = 36 - k * 6;
  g.fillStyle = mix("#0c0c12", "#bcbcc4", k * 0.8);
  g.beginPath();
  g.arc(cx, cy - 56, potR, 0, Math.PI);
  g.fill();
  rr(g, cx - potR - 3, cy - 60, potR * 2 + 6, 8, 4);
  // 中身:煮えたぎる七色
  const cols = [sat("#ff4040", "#e8e8ea"), sat("#ffb830", "#dcdce0"), sat("#52ff6a", "#cfcfd6"), sat("#31b8ff", "#c4c4cc"), sat("#c05aff", "#b9b9c2")];
  for (let i = 0; i < 5; i++) {
    const wob = Math.sin(t * 2 + i) * 3;
    g.fillStyle = cols[i];
    g.beginPath();
    g.arc(cx - 20 + i * 10 + wob, cy - 58, 8 - k * 2, Math.PI, Math.PI * 2);
    g.fill();
  }
  // 泡
  for (let i = 0; i < 6; i++) {
    const ph = (t * 0.9 + i * 0.19) % 1;
    g.globalAlpha = (1 - ph) * (1 - k * 0.7);
    g.fillStyle = cols[i % 5];
    g.beginPath();
    g.arc(cx - 22 + (i * 47) % 44, cy - 62 - ph * 14, 2.4 * (1 - ph * 0.5), 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 1;
  // 「にゃ」の湯気
  g.font = `9px ${FONT}`;
  for (let i = 0; i < 5; i++) {
    const ph = (t * 0.5 + i * 0.23) % 1;
    g.globalAlpha = (1 - ph) * 0.9;
    g.fillStyle = i % 2 ? cols[2] : cols[3];
    g.fillText("にゃ", cx - 16 + (i * 31) % 34, cy - 78 - ph * 26);
  }
  g.globalAlpha = 1;
  g.restore();
}

export function mix(a: string, b: string, k: number): string {
  const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
  const r = Math.round((pa >> 16) * (1 - k) + (pb >> 16) * k);
  const gg = Math.round(((pa >> 8) & 0xff) * (1 - k) + ((pb >> 8) & 0xff) * k);
  const bl = Math.round((pa & 0xff) * (1 - k) + (pb & 0xff) * k);
  return `rgb(${r},${gg},${bl})`;
}

// ---------------- ハート / ゲージ ----------------
export function drawHeart(g: Ctx2D, x: number, y: number, s: number, color: string) {
  g.fillStyle = color;
  g.beginPath();
  g.moveTo(x + s / 2, y + s);
  g.bezierCurveTo(x - s * 0.6, y + s * 0.35, x + s * 0.08, y - s * 0.32, x + s / 2, y + s * 0.22);
  g.bezierCurveTo(x + s * 0.92, y - s * 0.32, x + s * 1.6, y + s * 0.35, x + s / 2, y + s);
  g.fill();
}

export function drawHourglass(g: Ctx2D, x: number, y: number, frac: number, t: number) {
  g.save();
  g.strokeStyle = "#f0f0f4";
  g.lineWidth = 1.5;
  rrStroke(g, x, y, 14, 24, 3);
  // 砂(上)
  g.fillStyle = "#ffd93a";
  const upH = 8 * frac;
  g.fillRect(x + 3, y + 10 - upH, 8, upH);
  // 砂(下)
  g.fillRect(x + 3, y + 14, 8, 8 * (1 - frac));
  if (frac > 0.02) {
    g.fillRect(x + 6, y + 11, 2, 3 + Math.sin(t * 8) * 0.5);
  }
  g.restore();
}

export function rrStroke(g: Ctx2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
  g.stroke();
}

// ---------------- 背景(320x240) ----------------
const bgCache = new Map<string, HTMLCanvasElement>();

export function drawBG(g: Ctx2D, id: string, t: number) {
  const animated = id.startsWith("other") || id === "title" || id === "battle4" || id.startsWith("battle") || id === "grave";
  if (!animated) {
    let c = bgCache.get(id);
    if (!c) {
      c = document.createElement("canvas");
      c.width = 320; c.height = 240;
      const cg = c.getContext("2d")!;
      renderBG(cg, id, 0);
      bgCache.set(id, c);
    }
    g.drawImage(c, 0, 0);
  } else {
    renderBG(g, id, t);
  }
  // 未配置素材のラベル(仮の表示)
  g.save();
  g.globalAlpha = 0.22;
  g.fillStyle = id.startsWith("other") || id.startsWith("battle") ? "#ffffff" : "#3a3a40";
  g.font = `6px ${FONT}`;
  g.fillText(`assets/bg/${id}.png`, 4, 234);
  g.restore();
}

function renderBG(g: Ctx2D, id: string, t: number) {
  switch (id) {
    case "real_room": case "real_room_broken": realRoom(g, id === "real_room_broken"); break;
    case "real_hall": realHall(g); break;
    case "real_lounge": realLounge(g); break;
    case "real_station": realStation(g); break;
    case "real_canteen": realCanteen(g); break;
    case "real_courtyard": realCourtyard(g); break;
    case "real_visiting": realVisiting(g); break;
    case "other_hall": otherHall(g, t); break;
    case "other_canteen": otherCanteen(g, t); break;
    case "battle_123": battle123(g, t); break;
    case "battle4_0": case "battle4_1": case "battle4_2": case "battle4_3": case "battle4_4":
      battle4bg(g, t, Number(id.split("_")[1])); break;
    case "title": titleBg(g, t); break;
    case "bad1": bad1bg(g); break;
    case "bad2": bad2bg(g); break;
    case "bad3": bad3bg(g); break;
    case "bad4": bad4bg(g); break;
    case "bad5": bad5bg(g); break;
    case "bad6": bad6bg(g); break;
    case "bad7": bad7bg(g); break;
    case "grave": graveBg(g, t); break;
    case "entrance": entranceBg(g); break;
    case "white": g.fillStyle = "#ffffff"; g.fillRect(0, 0, 320, 240); break;
    default: g.fillStyle = "#101014"; g.fillRect(0, 0, 320, 240); break;
  }
}

function vignette(g: Ctx2D, a = 0.28) {
  const grad = g.createRadialGradient(160, 120, 80, 160, 120, 210);
  grad.addColorStop(0, "rgba(0,0,0,0)");
  grad.addColorStop(1, `rgba(0,0,0,${a})`);
  g.fillStyle = grad;
  g.fillRect(0, 0, 320, 240);
}

function realRoom(g: Ctx2D, broken: boolean) {
  g.fillStyle = "#e8e8ea"; g.fillRect(0, 0, 320, 240);
  // 床
  g.fillStyle = "#d4d4d8"; g.fillRect(0, 170, 320, 70);
  for (let i = 0; i < 9; i++) { g.fillStyle = "#c8c8cc"; g.fillRect(0, 176 + i * 8, 320, 1); }
  // 窓
  g.fillStyle = "#fafafc"; rr(g, 208, 26, 82, 92, 4);
  g.strokeStyle = "#b9b9bf"; g.lineWidth = 2; rrStroke(g, 208, 26, 82, 92, 4);
  g.strokeStyle = "#c9c9ce"; g.beginPath(); g.moveTo(249, 28); g.lineTo(249, 116); g.stroke();
  if (broken) {
    // 散乱
    g.save(); g.translate(70, 196); g.rotate(-0.5);
    g.fillStyle = "#acacb2"; g.fillRect(-30, -5, 66, 10); // 倒れたベッド柵
    g.restore();
    g.strokeStyle = "#9a9aa0"; g.lineWidth = 3;
    g.beginPath(); g.moveTo(240, 210); g.lineTo(284, 186); g.stroke(); // 倒れたスタンド
    g.fillStyle = "#8d8d93";
    for (let i = 0; i < 8; i++) g.fillRect(120 + (i * 37) % 120, 205 + (i * 13) % 22, 5, 3);
  } else {
    // ベッド
    g.fillStyle = "#efeff1"; rr(g, 26, 120, 110, 56, 5);
    g.fillStyle = "#dcdce0"; rr(g, 30, 124, 30, 22, 3);
    g.strokeStyle = "#adadb3"; g.lineWidth = 2; rrStroke(g, 26, 120, 110, 56, 5);
  }
  // カーテンの影
  g.fillStyle = "rgba(160,160,168,0.35)";
  g.fillRect(196, 20, 10, 104);
  vignette(g, 0.3);
}

function realHall(g: Ctx2D) {
  g.fillStyle = "#ececee"; g.fillRect(0, 0, 320, 240);
  // 遠近の廊下
  const cx = 160;
  g.fillStyle = "#dcdce0";
  g.beginPath(); g.moveTo(0, 240); g.lineTo(cx - 60, 120); g.lineTo(cx + 60, 120); g.lineTo(320, 240); g.closePath(); g.fill();
  g.fillStyle = "#c9c9cd";
  g.beginPath(); g.moveTo(cx - 60, 120); g.lineTo(cx - 26, 40); g.lineTo(cx + 26, 40); g.lineTo(cx + 60, 120); g.closePath(); g.fill();
  g.fillStyle = "#e4e4e8"; g.fillRect(cx - 26, 40, 52, 80);
  // ドア並び
  g.fillStyle = "#b4b4ba";
  for (let i = 0; i < 4; i++) {
    g.fillRect(cx - 58 + i * 6, 128 + i * 26, 4, 18 + i * 8);
    g.fillRect(cx + 54 - i * 6, 128 + i * 26, 4, 18 + i * 8);
  }
  // 蛍光灯
  g.fillStyle = "#fdfdff";
  rr(g, cx - 14, 60, 28, 5, 2);
  rr(g, cx - 20, 20, 40, 6, 2);
  g.fillStyle = "rgba(255,255,255,0.35)";
  g.fillRect(cx - 20, 66, 40, 30);
  vignette(g, 0.34);
}

function realLounge(g: Ctx2D) {
  g.fillStyle = "#e6e6e9"; g.fillRect(0, 0, 320, 240);
  g.fillStyle = "#d2d2d6"; g.fillRect(0, 160, 320, 80);
  // 棚(封筒)
  g.fillStyle = "#b2b2b8"; rr(g, 20, 40, 92, 70, 3);
  g.fillStyle = "#8f8f95"; g.fillRect(24, 62, 84, 3); g.fillRect(24, 86, 84, 3);
  g.fillStyle = "#f2f2f4";
  for (let i = 0; i < 7; i++) g.fillRect(30 + i * 11, 100, 9, 5); // 封筒7通
  // テレビ
  g.fillStyle = "#9a9aa0"; rr(g, 190, 44, 76, 54, 3);
  g.fillStyle = "#dbdbe0"; g.fillRect(196, 50, 64, 42);
  // ソファ
  g.fillStyle = "#c3c3c8"; rr(g, 130, 150, 120, 34, 8);
  vignette(g, 0.3);
}

function realStation(g: Ctx2D) {
  g.fillStyle = "#eaeaec"; g.fillRect(0, 0, 320, 240);
  g.fillStyle = "#d6d6da"; g.fillRect(0, 168, 320, 72);
  g.fillStyle = "#c9c9ce"; rr(g, 40, 96, 240, 44, 4);
  g.fillStyle = "#a9a9af"; g.fillRect(40, 96, 240, 5);
  g.fillStyle = "#f6f6f8";
  for (let i = 0; i < 4; i++) g.fillRect(58 + i * 56, 66, 34, 22); // モニター
  g.fillStyle = "#6e6e76"; // ナースコール灯
  g.fillRect(150, 40, 20, 6);
  vignette(g, 0.3);
}

function realCanteen(g: Ctx2D) {
  g.fillStyle = "#e9e9eb"; g.fillRect(0, 0, 320, 240);
  g.fillStyle = "#d3d3d7"; g.fillRect(0, 156, 320, 84);
  g.fillStyle = "#c4c4c9"; rr(g, 20, 30, 150, 40, 3); // 配膳口
  g.fillStyle = "#eeeeeF"; g.fillRect(26, 36, 138, 28);
  for (let i = 0; i < 3; i++) {
    g.fillStyle = "#bdbdc2";
    rr(g, 40 + i * 90, 120, 70, 24, 3);
  }
  vignette(g, 0.3);
}

function realCourtyard(g: Ctx2D) {
  g.fillStyle = "#f2f2f4"; g.fillRect(0, 0, 320, 240);
  g.fillStyle = "#d8d8dc"; g.fillRect(0, 120, 320, 120);
  g.fillStyle = "#c9c9ce";
  g.beginPath(); g.ellipse(80, 150, 46, 20, 0, 0, Math.PI * 2); g.fill(); // 植え込み
  g.beginPath(); g.ellipse(240, 180, 40, 16, 0, 0, Math.PI * 2); g.fill();
  g.fillStyle = "#a9a9ae"; rr(g, 150, 86, 14, 66, 4); // 木
  g.fillStyle = "#c3c3c8";
  g.beginPath(); g.arc(157, 70, 34, 0, Math.PI * 2); g.fill();
  g.fillStyle = "#b3b3b8"; rr(g, 190, 130, 70, 12, 3); // ベンチ
  vignette(g, 0.26);
}

function realVisiting(g: Ctx2D) {
  g.fillStyle = "#eaeaec"; g.fillRect(0, 0, 320, 240);
  g.fillStyle = "#d9d9dd"; g.fillRect(0, 168, 320, 72);
  g.fillStyle = "#fbfbfc"; rr(g, 216, 22, 74, 84, 4);
  g.strokeStyle = "#c2c2c7"; g.lineWidth = 2; rrStroke(g, 216, 22, 74, 84, 4);
  g.fillStyle = "#c6c6cb"; rr(g, 60, 128, 200, 26, 4); // 長机
  vignette(g, 0.3);
}

function otherSky(g: Ctx2D, t: number) {
  const grad = g.createLinearGradient(0, 0, 0, 240);
  grad.addColorStop(0, "#ff5d3a");
  grad.addColorStop(0.45, "#c2268a");
  grad.addColorStop(1, "#3d0f52");
  g.fillStyle = grad;
  g.fillRect(0, 0, 320, 240);
  // 熟れた果実のような天体
  for (let i = 0; i < 5; i++) {
    const bx = (i * 97 + 40) % 320;
    const by = 26 + ((i * 53) % 70) + Math.sin(t * 0.8 + i) * 4;
    const br = 10 + (i % 3) * 6;
    const gg = g.createRadialGradient(bx - 3, by - 3, 1, bx, by, br);
    gg.addColorStop(0, "#ffe14d");
    gg.addColorStop(1, "rgba(255,90,60,0)");
    g.fillStyle = gg;
    g.beginPath(); g.arc(bx, by, br, 0, Math.PI * 2); g.fill();
  }
}

function otherHall(g: Ctx2D, t: number) {
  otherSky(g, t);
  const cx = 160;
  // 歪んだ廊下
  g.fillStyle = "#5c1030";
  g.beginPath(); g.moveTo(0, 240); g.lineTo(cx - 74, 116); g.lineTo(cx + 74, 116); g.lineTo(320, 240); g.closePath(); g.fill();
  g.fillStyle = "#8a1250";
  g.beginPath(); g.moveTo(cx - 74, 116); g.lineTo(cx - 30, 30); g.lineTo(cx + 30, 30); g.lineTo(cx + 74, 116); g.closePath(); g.fill();
  g.fillStyle = "#a3123f"; g.fillRect(cx - 30, 30, 60, 86);
  // 溶けた蛍光灯
  for (let i = 0; i < 3; i++) {
    const ly = 44 + i * 26;
    const melt = 6 + Math.sin(t * 2 + i * 2) * 4;
    const hues = ["#ff4040", "#c05aff", "#52ff6a"];
    g.fillStyle = hues[i % 3];
    g.globalAlpha = 0.85;
    rr(g, cx - 16 + melt, ly, 32 - melt * 2, 5, 2);
    g.globalAlpha = 1;
    g.fillStyle = hues[i % 3] + "55";
    g.fillRect(cx - 20, ly + 5, 40, 16);
  }
  // 床の波
  g.strokeStyle = "rgba(224,64,251,0.4)";
  for (let i = 0; i < 6; i++) {
    g.beginPath();
    for (let x = 0; x <= 320; x += 8) {
      const y = 150 + i * 16 + Math.sin(x * 0.05 + t * 2 + i) * 3;
      if (x === 0) g.moveTo(x, y);
      else g.lineTo(x, y);
    }
    g.stroke();
  }
  // 浮遊する目玉
  for (let i = 0; i < 4; i++) {
    const ex = (i * 173 + t * 14) % 360 - 20;
    const ey = 90 + Math.sin(t * 1.2 + i * 2.2) * 26;
    g.fillStyle = "rgba(255,255,255,0.85)";
    g.beginPath(); g.ellipse(ex, ey, 5, 4, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = "#16001f";
    g.beginPath(); g.arc(ex, ey, 2, 0, Math.PI * 2); g.fill();
  }
  vignette(g, 0.22);
}

function otherCanteen(g: Ctx2D, t: number) {
  otherSky(g, t);
  g.fillStyle = "#2b0b3b"; g.fillRect(0, 140, 320, 100);
  // 蜜の川
  const honey = g.createLinearGradient(0, 130, 0, 200);
  honey.addColorStop(0, "#ffdf5e");
  honey.addColorStop(1, "#c47a00");
  g.fillStyle = honey;
  g.beginPath();
  g.moveTo(0, 160);
  for (let x = 0; x <= 320; x += 10) g.lineTo(x, 160 + Math.sin(x * 0.06 + t * 1.6) * 5);
  g.lineTo(320, 240); g.lineTo(0, 240); g.closePath(); g.fill();
  // 巣の格子
  g.strokeStyle = "rgba(255,223,94,0.5)";
  g.lineWidth = 2;
  for (let i = 0; i < 8; i++) {
    const hx = 20 + i * 40, hy = 30 + (i % 3) * 26;
    hexPath(g, hx, hy + Math.sin(t + i) * 3, 12);
    g.stroke();
  }
  vignette(g, 0.2);
}

function hexPath(g: Ctx2D, x: number, y: number, r: number) {
  g.beginPath();
  for (let i = 0; i < 6; i++) {
    const a = Math.PI / 3 * i + Math.PI / 6;
    const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
    if (i === 0) g.moveTo(px, py);
    else g.lineTo(px, py);
  }
  g.closePath();
}

function battle123(g: Ctx2D, t: number) {
  const grad = g.createLinearGradient(0, 0, 320, 240);
  grad.addColorStop(0, "#3d0f52");
  grad.addColorStop(0.5, "#8a1250");
  grad.addColorStop(1, "#240b34");
  g.fillStyle = grad;
  g.fillRect(0, 0, 320, 240);
  // うねるグリッド
  g.strokeStyle = "rgba(255,64,160,0.28)";
  g.lineWidth = 1;
  for (let i = 0; i < 10; i++) {
    g.beginPath();
    for (let x = 0; x <= 320; x += 8) {
      const y = i * 26 + Math.sin(x * 0.03 + t * 1.4 + i) * 6;
      if (x === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.stroke();
  }
  for (let i = 0; i < 14; i++) {
    g.beginPath();
    for (let y = 0; y <= 240; y += 8) {
      const x = i * 24 + Math.sin(y * 0.04 + t * 1.1 + i) * 5;
      if (y === 0) g.moveTo(x, y); else g.lineTo(x, y);
    }
    g.stroke();
  }
  // 光の円
  for (let i = 0; i < 6; i++) {
    const ph = (t * 0.22 + i * 0.17) % 1;
    g.strokeStyle = `rgba(255,225,77,${0.5 * (1 - ph)})`;
    g.lineWidth = 2;
    g.beginPath();
    g.arc(160, 90, ph * 160, 0, Math.PI * 2);
    g.stroke();
  }
  vignette(g, 0.3);
}

function battle4bg(g: Ctx2D, t: number, stage: number) {
  const k = stage / 4;
  const top = mix("#ff5d3a", "#e9e9ec", k);
  const mid = mix("#8a1250", "#dcdce2", k);
  const bot = mix("#2b0b3b", "#cfcfd6", k);
  const grad = g.createLinearGradient(0, 0, 0, 240);
  grad.addColorStop(0, top);
  grad.addColorStop(0.55, mid);
  grad.addColorStop(1, bot);
  g.fillStyle = grad;
  g.fillRect(0, 0, 320, 240);
  // ひび割れた空
  g.strokeStyle = `rgba(20,10,30,${0.5 - k * 0.3})`;
  g.lineWidth = 1.5;
  for (let i = 0; i < 7; i++) {
    g.beginPath();
    let cx = (i * 61) % 320, cy = 0;
    g.moveTo(cx, cy);
    for (let s2 = 0; s2 < 5; s2++) {
      cx += Math.sin(i * 7 + s2 * 3) * 22;
      cy += 16 + (i % 3) * 6;
      g.lineTo(cx, cy);
    }
    g.stroke();
  }
  // 雨のように降る「にゃ」
  g.font = `10px ${FONT}`;
  for (let i = 0; i < 12; i++) {
    const ph = (t * 0.3 + i * 0.09) % 1;
    g.fillStyle = i % 3 === 0 ? mix("#52ff6a", "#9a9aa2", k) : mix("#c05aff", "#a9a9b0", k);
    g.globalAlpha = 0.5 * (1 - k * 0.5);
    g.fillText("にゃ", (i * 83) % 320, ph * 240);
  }
  g.globalAlpha = 1;
  vignette(g, 0.25);
}

function titleBg(g: Ctx2D, t: number) {
  // モノクロ病棟 + 滴り落ちる虹
  realHall(g);
  g.fillStyle = "rgba(5,5,10,0.55)";
  g.fillRect(0, 0, 320, 240);
  // 虹のしずく
  for (let i = 0; i < 7; i++) {
    const ph = (t * 0.12 + i * 0.145) % 1;
    const y = ph * 260 - 20;
    g.fillStyle = RAINBOW[i];
    g.globalAlpha = 0.8 * (1 - ph * 0.6);
    g.beginPath();
    g.ellipse(160 + Math.sin(i * 2.1) * 4, y, 3, 7, 0, 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 1;
  // 着地した色
  const ph2 = (t * 0.12) % 1;
  for (let i = 0; i < 7; i++) {
    g.fillStyle = RAINBOW[i];
    g.globalAlpha = 0.14;
    g.beginPath();
    g.ellipse(160, 228, 10 + i * 7 * ph2, 4 + i * ph2, 0, 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 1;
}

// ---- バッドエンド背景 ----
function badBase(g: Ctx2D, tone = "#0c0c12") {
  g.fillStyle = tone; g.fillRect(0, 0, 320, 240);
}
function bad1bg(g: Ctx2D) {
  badBase(g);
  // 窓のない部屋・熟れた天井
  g.fillStyle = "#17171e"; g.fillRect(30, 60, 260, 150);
  g.strokeStyle = "#2a2a33"; g.strokeRect(30, 60, 260, 150);
  const grad = g.createRadialGradient(160, 40, 10, 160, 40, 150);
  grad.addColorStop(0, "rgba(255,93,58,0.55)");
  grad.addColorStop(0.5, "rgba(194,38,138,0.3)");
  grad.addColorStop(1, "rgba(61,15,82,0)");
  g.fillStyle = grad;
  g.beginPath(); g.ellipse(160, 50, 150, 55, 0, 0, Math.PI * 2); g.fill();
  for (let i = 0; i < 6; i++) {
    g.fillStyle = "rgba(255,255,255,0.16)";
    g.beginPath(); g.ellipse(90 + i * 28, 46, 7, 4.5, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = "rgba(22,0,31,0.8)";
    g.beginPath(); g.arc(90 + i * 28, 46, 2.4, 0, Math.PI * 2); g.fill();
  }
  g.fillStyle = "#101016"; g.fillRect(120, 160, 80, 40); // ベッドの影
  vignette(g, 0.5);
}
function bad2bg(g: Ctx2D) {
  badBase(g, "#101014");
  g.fillStyle = "#1d1d24"; rr(g, 90, 110, 140, 70, 6); // 皿
  g.fillStyle = "#3a3324"; rr(g, 110, 124, 100, 44, 4); // 冷めたトースト
  g.fillStyle = "rgba(255,255,255,0.06)";
  g.beginPath(); g.ellipse(160, 122, 50, 8, 0, 0, Math.PI * 2); g.fill();
  vignette(g, 0.55);
}
function bad3bg(g: Ctx2D) {
  bad3BgGrad(g);
  g.globalAlpha = 1;
  // 白い錠剤
  g.fillStyle = "rgba(255,255,255,0.85)";
  g.beginPath(); g.ellipse(160, 170, 14, 7, 0.4, 0, Math.PI * 2); g.fill();
  vignette(g, 0.5);
}
function bad3BgGrad(g: Ctx2D) {
  const grad = g.createLinearGradient(0, 0, 0, 240);
  grad.addColorStop(0, "#ff5d3a"); grad.addColorStop(1, "#3d0f52");
  g.fillStyle = grad; g.fillRect(0, 0, 320, 240);
  g.globalAlpha = 0.5;
  for (let i = 0; i < 5; i++) {
    g.fillStyle = ["#ff4040", "#c05aff", "#52ff6a", "#ffe14d", "#ff7dd2"][i];
    g.beginPath(); g.arc(50 + i * 55, 60 + (i % 2) * 40, 14, 0, Math.PI * 2); g.fill();
  }
}
function bad4bg(g: Ctx2D) {
  badBase(g, "#0a0a10");
  g.fillStyle = "#26262e"; rr(g, 40, 130, 240, 60, 8); // ベッド
  g.fillStyle = "#31313a"; rr(g, 50, 118, 50, 24, 6); // 枕
  // 窓辺に猫
  g.fillStyle = "rgba(240,240,250,0.14)"; g.fillRect(230, 30, 60, 84);
  drawMike(g, 250, 74, 0.3, 1, 0.9);
  vignette(g, 0.5);
}
function bad5bg(g: Ctx2D) {
  badBase(g, "#0e0e13");
  g.fillStyle = "#e6e6ea"; rr(g, 110, 90, 100, 64, 2); // 手紙
  g.fillStyle = "#b9b9c0"; g.fillRect(126, 106, 68, 6); // 宛名
  g.fillStyle = "#8e8e96"; g.fillRect(126, 126, 32, 4);
  vignette(g, 0.5);
}
function bad6bg(g: Ctx2D) {
  badBase(g, "#0c0c12");
  g.fillStyle = "#1c1c24"; rr(g, 120, 60, 80, 130, 4); // 閉じた扉
  g.strokeStyle = "#33333c"; rrStroke(g, 120, 60, 80, 130, 4);
  g.fillStyle = "#4a4a52"; g.beginPath(); g.arc(188, 126, 3, 0, Math.PI * 2); g.fill();
  vignette(g, 0.55);
}
function bad7bg(g: Ctx2D) {
  badBase(g, "#0a0a0d");
  // 箱と赤い首輪
  g.fillStyle = "#232329"; rr(g, 100, 110, 120, 74, 4);
  g.fillStyle = "#2e2e36"; rr(g, 108, 104, 104, 20, 3);
  // 首輪
  g.strokeStyle = "#c0161f";
  g.lineWidth = 5;
  g.beginPath(); g.arc(160, 152, 22, 0, Math.PI * 2); g.stroke();
  g.fillStyle = "#c9a437";
  g.beginPath(); g.arc(160, 176, 5, 0, Math.PI * 2); g.fill();
  g.fillStyle = "rgba(255,255,255,0.06)";
  g.beginPath(); g.ellipse(160, 110, 90, 16, 0, 0, Math.PI * 2); g.fill();
  vignette(g, 0.6);
}

// ---- トゥルーエンド(色のある現実) ----
function graveBg(g: Ctx2D, t: number) {
  const sky = g.createLinearGradient(0, 0, 0, 200);
  sky.addColorStop(0, "#8fd3ff");
  sky.addColorStop(1, "#e6f6ff");
  g.fillStyle = sky; g.fillRect(0, 0, 320, 240);
  // 雲
  g.fillStyle = "rgba(255,255,255,0.9)";
  for (let i = 0; i < 3; i++) {
    const cx = ((i * 140 + t * 8) % 420) - 50;
    g.beginPath();
    g.ellipse(cx, 36 + i * 18, 30, 9, 0, 0, Math.PI * 2);
    g.ellipse(cx + 18, 32 + i * 18, 20, 8, 0, 0, Math.PI * 2);
    g.fill();
  }
  // 緑の大地
  const gr = g.createLinearGradient(0, 150, 0, 240);
  gr.addColorStop(0, "#7ec96d"); gr.addColorStop(1, "#4d9650");
  g.fillStyle = gr; g.fillRect(0, 155, 320, 85);
  // 小さな石
  g.fillStyle = "#b9bcc4"; rr(g, 196, 132, 26, 36, 6);
  g.fillStyle = "#9ba0a8"; rr(g, 200, 138, 18, 6, 2);
  // 花
  const cols = ["#ff8fb3", "#ffe14d", "#ffffff"];
  for (let i = 0; i < 7; i++) {
    const fx = 186 + (i * 53) % 50, fy = 172 + (i * 29) % 18;
    g.strokeStyle = "#3d7a42"; g.lineWidth = 1;
    g.beginPath(); g.moveTo(fx, fy + 6); g.lineTo(fx, fy); g.stroke();
    g.fillStyle = cols[i % 3];
    g.beginPath(); g.arc(fx, fy, 2.6, 0, Math.PI * 2); g.fill();
  }
  // 手を合わせる二人の影
  g.fillStyle = "rgba(30,40,60,0.55)";
  g.beginPath(); g.ellipse(150, 158, 8, 18, 0, 0, Math.PI * 2); g.fill();
  g.beginPath(); g.ellipse(168, 160, 6, 14, 0, 0, Math.PI * 2); g.fill();
  vignette(g, 0.12);
}
function entranceBg(g: Ctx2D) {
  const sky = g.createLinearGradient(0, 0, 0, 240);
  sky.addColorStop(0, "#ffd9a8"); sky.addColorStop(0.6, "#fff3e0"); sky.addColorStop(1, "#ffffff");
  g.fillStyle = sky; g.fillRect(0, 0, 320, 240);
  // 入口の白い建築
  g.fillStyle = "#f2f2f6"; g.fillRect(40, 30, 240, 180);
  g.fillStyle = "#ffffff"; rr(g, 120, 70, 80, 140, 6);
  const gl = g.createLinearGradient(0, 70, 0, 210);
  gl.addColorStop(0, "rgba(255,214,140,0.95)");
  gl.addColorStop(1, "rgba(255,255,255,0.7)");
  g.fillStyle = gl; rr(g, 130, 80, 60, 130, 4);
  // 並んで歩く二人
  g.fillStyle = "rgba(60,50,70,0.85)";
  g.beginPath(); g.ellipse(146, 188, 7, 17, 0, 0, Math.PI * 2); g.fill();
  g.beginPath(); g.arc(146, 166, 6, 0, Math.PI * 2); g.fill();
  g.beginPath(); g.ellipse(170, 190, 6, 15, 0, 0, Math.PI * 2); g.fill();
  g.beginPath(); g.arc(170, 170, 5, 0, Math.PI * 2); g.fill();
  // 手すりの影
  g.strokeStyle = "rgba(120,110,130,0.5)";
  g.beginPath(); g.moveTo(60, 180); g.lineTo(120, 200); g.stroke();
  vignette(g, 0.1);
}

// ---------------- 戦闘アタックバー ----------------
export function drawAttackBar(
  g: Ctx2D, x: number, y: number, w: number, h: number,
  lineX: number | null, critHalf: number, active: boolean, t: number
) {
  g.save();
  const cxr = (f: number) => x + w * (0.5 + f);
  // 帯
  g.fillStyle = active ? "#471b1b" : "#2e2e33";
  g.fillRect(x, y, w, h);
  g.fillStyle = active ? "#c9a437" : "#57575e";
  g.fillRect(x + w * 0.12, y, w * 0.76, h);
  g.fillStyle = active ? "#3fae62" : "#55555c";
  g.fillRect(cxr(-critHalf), y, w * critHalf * 2, h);
  g.strokeStyle = active ? "#f2f2f6" : "#7a7a82";
  g.lineWidth = 1.5;
  g.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  if (lineX !== null) {
    g.fillStyle = "#ffffff";
    g.shadowColor = "#ffffff";
    g.shadowBlur = active ? 6 + Math.sin(t * 10) * 2 : 0;
    g.fillRect(x + w * lineX - 1.5, y - 3, 3, h + 6);
  }
  g.restore();
}
