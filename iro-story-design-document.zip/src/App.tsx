import { useEffect, useRef } from "react";
import { initGame } from "./game/main";

export default function App() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    const dispose = initGame(ref.current);
    return () => {
      dispose();
    };
  }, []);

  return (
    <div className="h-full w-full bg-[#060608] flex items-center justify-center overflow-hidden">
      <div ref={ref} className="flex flex-col items-center" />
    </div>
  );
}
